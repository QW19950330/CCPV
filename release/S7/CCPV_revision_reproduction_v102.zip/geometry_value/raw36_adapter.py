"""Pure-memory bridge from frozen six-path response batches to original Raw36.
No file reads, labels, fitted parameters, readouts, world model, or RNG calls.
The original feature functions are vendored byte-for-byte and SHA-verified.
"""
from pathlib import Path
import hashlib
import importlib.util
import numpy as np

MATH_SHA256 = 'b6d999ffd4a1fa05d0eee2d2a94dbc8d977a25ba4a762d221b68b5c13bd14927'
_math_path = Path(__file__).with_name('frozen_value_math.py')
if hashlib.sha256(_math_path.read_bytes()).hexdigest() != MATH_SHA256:
    raise RuntimeError('Frozen Raw36 mathematics changed')
_spec = importlib.util.spec_from_file_location('_ccpv_test_frozen_value_math', _math_path)
M = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(M)
TEST_PATHS = ('natural', 'none_every_step', 'first_A', 'persistent_A',
              'maintained_v0_A', 'first_provenance_only_A')
PREFIX_KEYS = ('history_states', 'history_valid', 'history_position_valid', 'entity_ids',
               'teams', 'source_indices', 'match_ids', 'source_frame_ids', 'frame_times_s',
               'operator_candidate_slots', 'operator_candidate_ids', 'identity_status',
               'operator_case_status', 'technical_unsupported')
SAVED_KEYS = ('states', 'support', 'completed_steps', 'status', 'source_indices',
              'match_ids', 'actor_slots', 'technical_unsupported')


def _array(a, key):
    x = np.asarray(a[key])
    if x.dtype.hasobject:
        raise ValueError('Object arrays are outside the saved-path contract: ' + key)
    return x


def prepare_prefix_batch(prefix):
    """Validate one caller-bound batch, retaining original missing-feature semantics.

    The caller owns full-file SHA/cell binding. Both source-home candidates remain
    required by the already frozen input qualification, although only A is edited.
    Actor and technical fields are consistency checks, not new Raw36 filtering.
    """
    missing = set(PREFIX_KEYS) - set(prefix)
    if missing:
        raise ValueError('Missing prefix fields: ' + str(sorted(missing)))
    a = {k: _array(prefix, k) for k in PREFIX_KEYS}
    h, v, pv, ids = (a[k] for k in ('history_states', 'history_valid',
                                   'history_position_valid', 'entity_ids'))
    n = len(h)
    M.validate_prefix(h, v, pv, ids, a['teams'])
    expected_shapes = dict(source_indices=(n,), match_ids=(n,),
        source_frame_ids=(n, 10), frame_times_s=(n, 10),
        operator_candidate_slots=(n, 2), operator_candidate_ids=(n, 2),
        identity_status=(n, 23), operator_case_status=(n,), technical_unsupported=(n,))
    for k, shape in expected_shapes.items():
        if a[k].shape != shape:
            raise ValueError('Prefix field shape mismatch: ' + k)
    if a['technical_unsupported'].dtype != bool:
        raise ValueError('Technical flag must be boolean')
    if not np.issubdtype(a['operator_candidate_slots'].dtype, np.integer):
        raise ValueError('Actor slots must be integer')
    if not np.issubdtype(a['source_indices'].dtype, np.integer):
        raise ValueError('Source indices must be integer')
    if len(np.unique(a['source_indices'])) != n:
        raise ValueError('Duplicate source indices in a saved batch')
    if not np.all(np.diff(a['source_frame_ids'], axis=1) == 1):
        raise ValueError('Nonconsecutive history source frames')
    if not np.allclose(np.diff(a['frame_times_s'], axis=1), .1, rtol=0, atol=1e-8):
        raise ValueError('History time spacing differs from original 10 Hz contract')
    source_actor_ok = a['operator_case_status'].astype(str) == 'SUPPORTED_TWO_SOURCE_HOME_T0_VALID'
    for r in range(n):
        slots = a['operator_candidate_slots'][r]
        if source_actor_ok[r]:
            if (len(set(slots.tolist())) != 2 or not np.all((slots >= 0) & (slots < 11))
                    or not v[r, -1, slots].all()
                    or not np.array_equal(ids[r, slots], a['operator_candidate_ids'][r])
                    or not np.all(a['identity_status'][r, slots] == 'VERIFIED_SOURCE_PLAYER_TEAM')):
                raise ValueError('Frozen two-source-home actor binding mismatch')
        elif np.any(slots >= 0):
            raise ValueError('Unsupported prepared row unexpectedly supplies actor slots')
    initial_eligible = source_actor_ok & ~a['technical_unsupported']
    x0, cv8, prefix_supported = M.prefix_features(h, v, ids)
    return dict(arrays=a, X0=x0, old_CV8=cv8, prefix_supported=prefix_supported,
                initial_eligible=initial_eligible, history_seen=v.any(1))


def extract_batch(prefix, saved):
    """Return Raw36[B,6,36] and supported[B,6] for one complete saved batch.

    Score support is exactly original Raw36 prefix presence AND completed20.
    Initial eligibility, source IDs, and full generated support are independent
    saved-run contract assertions. Missing numeric features remain NaN for the
    old head's frozen missing indicators; partial paths are never imputed.
    """
    c = prepare_prefix_batch(prefix)
    a = c['arrays']
    n = len(a['history_states'])
    missing = set(SAVED_KEYS) - set(saved)
    if missing:
        raise ValueError('Missing saved fields: ' + str(sorted(missing)))
    z = {k: _array(saved, k) for k in SAVED_KEYS}
    shapes = dict(states=(n, 6, 20, 23, 4), support=(n, 6, 20, 23),
                  completed_steps=(n, 6), status=(n, 6), source_indices=(n,),
                  match_ids=(n,), actor_slots=(n,), technical_unsupported=(n,))
    for k, shape in shapes.items():
        if z[k].shape != shape:
            raise ValueError('Saved batch shape mismatch: ' + k)
    if z['states'].dtype != np.float32 or z['support'].dtype != bool:
        raise ValueError('Saved states/support dtype mismatch')
    if (not np.issubdtype(z['completed_steps'].dtype, np.integer)
            or z['technical_unsupported'].dtype != bool):
        raise ValueError('Saved steps/technical dtype mismatch')
    for key in ('source_indices', 'match_ids', 'technical_unsupported'):
        if not np.array_equal(z[key], a[key]):
            raise ValueError('Saved/prefix row binding mismatch: ' + key)
    if not np.array_equal(z['actor_slots'], a['operator_candidate_slots'][:, 0]):
        raise ValueError('Saved first-actor slot binding mismatch')
    if 'paths' in saved and tuple(np.asarray(saved['paths']).astype(str)) != TEST_PATHS:
        raise ValueError('Saved six-path order mismatch')
    for key in ('states', 'support', 'completed_steps', 'status'):
        if not np.array_equal(z[key][:, 0], z[key][:, 1], equal_nan=(key == 'states')):
            raise ValueError('Natural and NONE must retain exact saved parity: ' + key)
    eligible = c['initial_eligible']
    complete = z['completed_steps'] == 20
    if np.any(complete != (z['status'].astype(str) == 'COMPLETED')):
        raise ValueError('Completed-step/status mismatch')
    if np.any(complete & ~eligible[:, None]):
        raise ValueError('A completed path violates frozen input eligibility')
    if np.any(z['completed_steps'][~eligible] != 0) or z['support'][~eligible].any():
        raise ValueError('Ineligible input has generated supported states')
    if np.any(z['status'][~eligible].astype(str) != 'UNSUPPORTED_PREPARED'):
        raise ValueError('Ineligible input has unexpected saved status')
    if not np.array_equal(complete[:, 0], eligible):
        raise ValueError('Natural path has lost a frozen eligible row')
    raw = np.full((n, 6, 36), np.nan, np.float64)
    for pi, name in enumerate(TEST_PATHS):
        x, done = M.path_features(a['history_states'], a['history_valid'], a['entity_ids'],
                                  z['states'][:, pi], z['support'][:, pi],
                                  z['completed_steps'][:, pi], c['X0'], c['old_CV8'])
        if np.any(z['support'][done, pi] != np.broadcast_to(c['history_seen'][done, None],
                                                         (int(done.sum()), 20, 23))):
            raise ValueError('Completed path changed historical entity support: ' + name)
        raw[:, pi] = x
    supported = complete & c['prefix_supported'][:, None]
    return dict(Raw36=raw, supported=supported, complete=complete,
                prefix_supported=c['prefix_supported'], initial_eligible=eligible,
                X0=c['X0'], old_CV8=c['old_CV8'], paths=np.asarray(TEST_PATHS),
                status=z['status'].copy(), completed_steps=z['completed_steps'].copy(),
                source_indices=a['source_indices'].copy(), match_ids=a['match_ids'].copy(),
                fixed_team_A=np.zeros(n, np.int64),
                target_source_ids=a['operator_candidate_ids'].copy())
