# Real possession endings, shot geometry and the stationary control

These scripts reproduce the v97/v98 comparison of frozen trajectory readouts against the observed ending of a home player’s possession. The endpoint is a shot versus a pass within 100 frames of the decision, at 10 Hz. All results refer to natural recorded play. Results on the four assessment fixtures had been inspected in earlier work and are retrospective.

## Start here for an offline check

From this directory, run `python -I -B replay_aggregates.py`. It uses the Python standard library and the accompanying fixture-level `aggregate/fixture_metrics.csv`. The 640 rows contain one aggregate value per fixture, method, calibration scheme, reader and seed on the full 690-possession cohort. Fixtures have within-study labels A–D, with 27 observed shots across the four fixtures. No player, possession or window records are required.

The script subtracts methods **within each fixture**, averages the four differences with equal fixture weight, then reports each seed, the five-seed mean and the sample SD. With the CV-trained reader, A+D had lower log loss than A+HOLD for **zero of five** seeds after calibrating on four fixtures, and **three of five** after calibrating on sixteen fixtures. Use `python -I -B replay_aggregates.py --output paired_metrics.csv` to write every v97/v98 full-cohort contrast across the two readers, two calibration schemes and five metrics. The offline check verified 1,400 values against the historical individual-seed and summary tables. This layer reproduces the published aggregation starting from fixture metrics. Verifying which individual cases qualified requires the case-level inputs below.

## What was rerun

| Calculation | Inputs used in the verification run | Result |
|---|---|---|
| Recorded outcome and decision-time geometry | 20 provider tracking files, 20 match/roster files, 20 event files, the frozen source-window index and historical cohort membership | 24,826 decision windows checked. Event type, owner check and time to ending matched for every retained case. All three original geometry tables matched byte for byte. |
| Stationary trajectory and frozen inference | Three prepared prefix archives, retained case keys, and 60 published Direct heads (two readers, five seeds, six folds) | Reconstructed 20 stationary future steps, calculated 36 features, applied the heads and combined their probabilities. All 31,340 HOLD values and missingness indicators matched across the three CSVs. |
| Endpoint fitting and scoring | Retained cases, geometry, HOLD and the original natural CV/D readout CSVs | Refit the four- and sixteen-fixture endpoint models. Compared 20 tables, including the individual fixture, individual seed and paired results. All 5,624 data rows and every CSV field matched. |

The split contains four calibration fixtures, twelve additional development fixtures and four separate assessment fixtures. Raw event rules admitted 582, 1,862 and 694 possessions. The historical assessment table contains 690 cases (27 shots). The raw check verifies that all 690 are among the 694 eligible possessions. The four excluded cases were passes. The historical assessment input supplies that final score-support decision. Across the broader calibration cohort, lead times, roster checks and t0 geometry are reconstructed, including missing detections. Endpoint fitting used 579 cases (10 shots) or 2,426 cases (50 shots) after requiring common support.

For the primary CV-trained reader on the 690 possessions, adding the learned forecast to angle and distance changes equal-fixture log loss by **+0.000591 ± 0.000311** relative to the stationary readout with four calibration fixtures. After calibration on sixteen fixtures, the difference is **−0.000207 ± 0.000298**. These are five-seed means and sample standard deviations. Lower log loss is better. The comparison does not establish a consistent advantage from future motion. It also cannot measure what would have happened had a player taken an edited action.

## Supply the historical inputs

Use plain Python (keep assertions enabled). The verification host used Python 3.11.5, NumPy 1.26.4, pandas 2.3.1 and SciPy 1.11.1 on Windows. Keep `frozen_value_math.py` byte-exact when extracting or checking out the code. It is an immutable dependency of `raw36_adapter.py`. Each command requires a new output directory.

| Input | Origin and expected structure |
|---|---|
| `--matches` | Separately obtained SkillCorner Open Data snapshot `4340d274572876239c154c90bc507a9b3250a656`, directory `data/matches/`. Each fixture directory contains the same-ID `_match.json`, `_tracking_extrapolated.jsonl` and `_dynamic_events.csv` files. The event files are required for the recorded outcome. [Provider snapshot](https://github.com/SkillCorner/opendata/tree/4340d274572876239c154c90bc507a9b3250a656) |
| `--cache` | Original 20-fixture `skillcorner_10hz.npz`. Source-row indices and period/frame identifiers define each decision window. See the companion `guide/rebuild_skillcorner_prefixes.py` for the raw-to-cache and four-fixture test-prefix route. |
| `--candidates` / `--inputs` | Historical v97 cohort directory. For each split `calibration`, `dev12`, `test`, supply `<split>_candidates.csv` (source, fixture, period, frame, observed outcome, distance, ownership and lead) and `<split>_scores.csv` (`source,match,world,family,seed,q`). The two score worlds are CV and D. Both Direct reader families and seeds 0–4 are required. Missing values retain their historical meaning. |
| `--calibration`, `--dev12`, `--test` | Hash-bound v97/prepared prefix NPZ for the 582 eligible possessions among 4,948 calibration windows and 1,862 eligible possessions among 14,886 development windows, and the 4,992-row test prefix shared with the trajectory replay. Required arrays are enumerated in `raw36_adapter.PREFIX_KEYS`. They include ten observed states per window, masks, slot/ID mappings, times, fixture/source identifiers and original technical-support flags. The current route takes the first two private prefix archives as inputs. |
| `--weights` | Supply the intact `CCPV_clean_inference_weights_local_candidate_20261119_v1.zip` from the published record. The code verifies its SHA-256 and each of 60 selected inference heads before use. [Published companion archives](https://doi.org/10.5281/zenodo.24370617) |

The candidate source package includes scientific code, checksums and aggregate verification only. The historical natural forecasts and readout CSVs enter as fixed inputs at this stage. This run did not regenerate natural trajectories, construct the two non-test prefix archives covering sixteen fixtures from raw tracking, or fit neural weights. Input availability therefore matters for reproducing the entire endpoint chain from scratch. A comparison using new fixtures would require a separately declared cohort and checksum set. Generated geometry and score outputs include source/window keys and must be handled according to the underlying data terms.

## Run the checks

Run from this directory, substituting your own relative paths. Only the raw-event check needs the provider match directory. The scoring command can also be rerun with existing hash-matching geometry and HOLD outputs.

```text
python -X utf8 -B recorded_endings.py --matches private/provider/data/matches --cache private/skillcorner_10hz.npz --candidates private/cohort --output replay/geometry
python -X utf8 -B stationary.py --calibration private/calibration_prefixes.npz --dev12 private/dev12_prefixes.npz --test private/test_prefixes.npz --weights private/CCPV_clean_inference_weights_local_candidate_20261119_v1.zip --candidates private/cohort --output replay/hold
python -X utf8 -B replay_models.py --inputs private/cohort --geometry replay/geometry --hold replay/hold --output replay/models
```

`verification.json` records the completed run. `frozen_checks.json` lists each reference digest, including hashes of CSVs with normalized line endings for cross-platform comparison. Individual generated tables appear in `replay/models/distance/results`, `replay/models/distance/expanded/results` and `replay/models/geometry_and_hold/results`. Model comparisons weight fixtures equally. The five seeds describe variation across frozen model initializations on these same matches.
