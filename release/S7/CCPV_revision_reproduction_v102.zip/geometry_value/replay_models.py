"""Refit the 4- and 16-fixture endpoint models, then score the frozen 4-fixture assessment cohort."""
import argparse
import hashlib
from pathlib import Path

import pandas as pd

import distance_models as distance
import geometry_models as geometry

CHECKS = Path(__file__).with_name("frozen_checks.json")


def main(args):
    checks = distance.load_json(CHECKS)
    groups = {}
    for split, expected in checks["splits"].items():
        candidate = args.inputs / f"{split}_candidates.csv"
        assert distance.sha(candidate) == expected["candidates"]
        # Read only fixture IDs for the frozen split, never outcomes for choosing fixtures.
        groups[split] = sorted(pd.read_csv(candidate, usecols=["match"], dtype={"match":str}).match.unique())
        assert distance.sha(args.inputs / f"{split}_scores.csv") == expected["scores"]
        assert distance.sha(args.geometry / f"{split}.csv") == expected["geometry"]
        assert distance.sha(args.hold / f"{split}.csv") == expected["hold"]
    assert [len(groups[s]) for s in ("calibration","dev12","test")] == [4,12,4]
    assert len(set().union(*[set(ids) for ids in groups.values()])) == 20

    args.output.mkdir(parents=True, exist_ok=False)
    distance.HERE = args.output / "distance"
    distance.HERE.mkdir()
    distance.LOCAL = args.inputs
    plan = dict(calibration_matches=groups["calibration"], assessment_matches=groups["test"])
    distance.save_json(distance.HERE / "protocol.json", plan)
    distance.save_json(distance.HERE / "expanded_protocol.json",
                       dict(prior=distance.sha(distance.HERE / "protocol.json"), calibration_extra_matches=groups["dev12"]))
    for expanded in [False,True]:
        distance.fit(plan, expanded=expanded)
    for expanded in [False,True]:
        distance.evaluate(plan, expanded=expanded)

    geometry.HERE = args.output / "geometry_and_hold"
    geometry.HERE.mkdir()
    geometry.V97 = distance.HERE
    geometry.INPUT_DIRS = {"geometry":args.geometry, "hold":args.hold}
    distance.save_json(geometry.HERE / "protocol.json", dict(checks=distance.sha(CHECKS),
                       arms=["G","A","A+HOLD","A+CV","A+D"], schemes=["four","sixteen"], seeds=list(range(5))))
    geometry.fit()
    geometry.evaluate()
    sources = {"distance_four": distance.HERE / "results",
               "distance_sixteen":distance.HERE / "expanded/results",
               "geometry_and_hold":geometry.HERE / "results"}
    verified = {}
    for model, root in sources.items():
        expected = checks["tables_lf"][model]
        assert {p.name for p in root.glob("*.csv")} == set(expected)
        verified[model] = {}
        for filename, expected_sha in expected.items():
            data = (root / filename).read_bytes().replace(b"\r\n",b"\n")
            sha = hashlib.sha256(data).hexdigest()
            if sha != expected_sha:
                raise ValueError(f"Historical table differs: {model}/{filename}. Compare the numerical environment and inputs.")
            verified[model][filename] = dict(data_rows=len(data.splitlines())-1, sha256_lf=sha)
    distance.save_json(args.output / "verification.json", dict(tables=verified, model_seeds=5,
                       calibration_counts=[4,16], independent_assessment_matches=4, assessment_cases=690, shots=27))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True, help="Frozen candidate and natural-score CSV directory")
    parser.add_argument("--geometry", type=Path, required=True, help="Output directory from recorded_endings.py")
    parser.add_argument("--hold", type=Path, required=True, help="Output directory from stationary.py")
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
