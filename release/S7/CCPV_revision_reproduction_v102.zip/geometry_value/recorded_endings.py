"""Reconstruct actual possession endings and decision-time geometry from licensed provider files."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re

import numpy as np
import pandas as pd

import distance_models as stats

CONFIG = Path(__file__).with_name("frozen_checks.json")
FRAME = re.compile(rb'\s*\{\s*"frame"\s*:\s*(\d+)')
FIELDS = ["event_type", "event_id", "period", "frame_start", "frame_end", "team_id", "player_id", "end_type"]


def selected_tracking(path, wanted):
    selected = {}
    digest = hashlib.sha256()
    frames = {f for _, f in wanted}
    with path.open("rb") as handle:
        for line in handle:
            digest.update(line)
            header = FRAME.match(line)
            if header is None:
                raise ValueError("Unexpected tracking record")
            number = int(header[1])
            if number in frames:
                row = json.loads(line)
                key = int(row["period"]), number
                if key in wanted:
                    assert key not in selected
                    selected[key] = row["possession"], row.get("ball_data") or {}
    assert set(selected) == wanted
    return selected, digest.hexdigest()


def angle(x, y, goal_x):
    left = (goal_x - x, 3.66 - y)
    right = (goal_x - x, -3.66 - y)
    if math.hypot(*left) == 0 or math.hypot(*right) == 0:
        return math.nan
    return math.atan2(abs(left[0]*right[1] - left[1]*right[0]), left[0]*right[0] + left[1]*right[1])


def geometry(q, meta, ball):
    length, width = float(meta["pitch_length"]), float(meta["pitch_width"])
    side = meta["home_team_side"][q.half - 1]
    assert side in ("left_to_right", "right_to_left")
    sign = 1 if side == "left_to_right" else -1
    goal = sign * length / 2
    x, y = ball.get("x"), ball.get("y")
    valid = ball.get("is_detected") is True and x is not None and y is not None and np.isfinite([x, y]).all()
    record = dict(source=q.source, match=q.match, half=q.half, frame=q.frame, metres=np.nan, angle_rad=np.nan,
                  ball_x_m=np.nan, ball_y_m=np.nan, goal_x_m=goal, pitch_length_m=length, pitch_width_m=width,
                  longitudinal_m=np.nan, abs_lateral_m=np.nan, bearing_abs_rad=np.nan, ball_geometry_valid=bool(valid),
                  angle_valid=False, geometry_reason="missing_or_not_detected_t0_ball")
    if valid:
        x, y = float(x), float(y)
        a = angle(x, y, goal)
        forward = sign * (goal - x)
        record.update(metres=float(np.hypot(x-goal, y)), angle_rad=a, ball_x_m=x, ball_y_m=y, longitudinal_m=forward,
                      abs_lateral_m=abs(y), bearing_abs_rad=math.atan2(abs(y), forward), angle_valid=math.isfinite(a),
                      geometry_reason="detected_finite_t0_ball" if math.isfinite(a) else "ball_exactly_at_goal_post_angle_undefined")
    return record


def fixture(directory, queries, hashes, allow_missing_away):
    match = directory.name
    meta_path = directory / f"{match}_match.json"
    events_path = directory / f"{match}_dynamic_events.csv"
    tracking_path = directory / f"{match}_tracking_extrapolated.jsonl"
    meta = stats.load_json(meta_path)
    assert str(meta["id"]) == match
    hashes["metadata"].append(stats.sha(meta_path))
    hashes["events"].append(stats.sha(events_path))
    phases = {int(r["period"]): (int(r["start_frame"]), int(r["end_frame"])) for r in meta["match_periods"]}
    roster = {int(r["id"]): int(r["team_id"]) for r in meta["players"]}
    home = meta["home_team"]["id"]
    intervals = pd.read_csv(events_path, usecols=FIELDS, dtype={"event_id":str}).query("event_type=='player_possession'")
    assert intervals.event_id.is_unique and intervals.event_id.notna().all()
    assert (intervals.frame_end >= intervals.frame_start).all()
    missing_away = 0
    for row in intervals.itertuples():
        player, team = int(row.player_id), int(row.team_id)
        if player in roster:
            assert roster[player] == team
        else:
            assert allow_missing_away and team != home
            missing_away += 1
    frames, digest = selected_tracking(tracking_path, set(zip(queries.half, queries.frame)))
    hashes["tracking"].append(digest)
    seen = set()
    admitted = []
    for half, frame_group in queries.groupby("half"):
        rows = intervals[intervals.period == half]
        starts, ends = rows.frame_start.to_numpy(), rows.frame_end.to_numpy()
        events = list(rows.itertuples())
        for q in frame_group.sort_values(["frame", "source"]).itertuples():
            active = np.flatnonzero((starts <= q.frame) & (q.frame < ends))
            if len(active) != 1:
                continue
            event = events[active[0]]
            if int(event.team_id) != home or event.event_id in seen:
                continue
            # Select the first available anchor before applying any outcome, owner, or geometry condition.
            seen.add(event.event_id)
            lo, hi = phases[int(half)]
            owner, ball = frames[int(half), q.frame]
            owner_id = owner.get("player_id")
            exact = owner_id is not None and int(owner_id) == int(event.player_id)
            lead = int(event.frame_end) - q.frame
            if (not (lo <= q.frame <= hi and lo <= event.frame_end <= hi)
                or q.frame + 100 > hi or (owner.get("group") or "").strip().lower() != "home team"
                or (owner_id is not None and not exact) or not 0 < lead <= 100 or event.end_type not in ("shot","pass")):
                continue
            admitted.append((geometry(q, meta, ball), (event.end_type, exact, lead)))
    return admitted, missing_away


def main(args):
    frozen = stats.load_json(CONFIG)
    assert stats.sha(args.cache) == frozen["source_cache"]
    args.output.mkdir(parents=True, exist_ok=False)
    cut = {"calibration":"validation_indices", "dev12":"train_indices", "test":"test_indices"}
    hashes = defaultdict(list)
    flow = {}
    with np.load(args.cache, allow_pickle=False) as archive:
        matches, halves = archive["match_ids"], archive["source_period"]
        t0 = archive["source_frame_ids"][:, 9]
        for name, field in cut.items():
            idx = archive[field]
            query = pd.DataFrame(dict(source=idx, match=[s.split(":")[-1] for s in matches[idx]],
                                      half=halves[idx], frame=t0[idx]))
            assert query.source.is_unique and not query.duplicated(["match","half","frame"]).any()
            ref = args.candidates / f"{name}_candidates.csv"
            assert stats.sha(ref) == frozen["splits"][name]["candidates"]
            expected = pd.read_csv(ref, dtype={"match":str}, float_precision="round_trip").set_index("source", verify_integrity=True)
            accepted = {}
            missing_away = 0
            for match, group in query.groupby("match", sort=True):
                admitted, exceptions = fixture(args.matches / match, group, hashes, name == "dev12")
                missing_away += exceptions
                for row, outcome in admitted:
                    assert row["source"] not in accepted
                    accepted[row["source"]] = row, outcome
            assert missing_away == int(name == "dev12")
            if name != "test":
                assert set(accepted) == set(expected.index)
            # The earlier test cohort supplied only rows on common geometry AND saved-score support.
            assert set(expected.index) <= set(accepted)
            out = []
            for sid, original in expected.iterrows():
                row, outcome = accepted[sid]
                assert (row["match"], row["half"], row["frame"]) == (original.match, original.half, original.frame)
                assert outcome == (original.outcome, original.exact_owner, original.lead_frames)
                np.testing.assert_allclose(row["metres"], original.metres, rtol=0, atol=2e-12, equal_nan=True)
                out.append(row)
            geo = pd.DataFrame(out)
            assert int(geo.ball_geometry_valid.sum()) == frozen["splits"][name]["detected_ball"]
            output = args.output / f"{name}.csv"
            geo.to_csv(output, index=False, mode="x", float_format="%.17g", na_rep="NA", lineterminator="\n")
            assert stats.sha(output) == frozen["splits"][name]["geometry"]
            flow[name] = dict(planned=len(query), provider_eligible=len(accepted), retained=len(out),
                              retained_shots=int(expected.outcome.eq("shot").sum()),
                              provider_eligible_shots=sum(outcome[0]=="shot" for _,outcome in accepted.values()),
                              detected_ball=int(geo.ball_geometry_valid.sum()), geometry_sha256=stats.sha(output))
            print(name, flow[name], flush=True)
    assert {k:sorted(v) for k,v in hashes.items()} == frozen["source_fingerprints"]
    stats.save_json(args.output / "verification.json", dict(raw_source_files_verified=60, splits=flow))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--matches", type=Path, required=True, help="Provider data/matches directory")
    parser.add_argument("--cache", type=Path, required=True, help="Frozen 20-match prepared source archive")
    parser.add_argument("--candidates", type=Path, required=True, help="Private cohort CSV directory")
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
