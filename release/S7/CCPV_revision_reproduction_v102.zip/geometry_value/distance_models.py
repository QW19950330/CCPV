"""Incremental prediction of a recorded possession ending. Use 'fit' before 'evaluate'."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from scipy.stats import rankdata

HERE = None  # output folder supplied by the runner
LOCAL = None  # private frozen candidate and score tables
READERS = ("CV-DirectWith", "D-DirectWith")
METRICS = ("logloss", "brier", "auc", "bias", "abs_bias")
SEEDS = range(5)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save_json(path, data):
    with path.open("x", encoding="utf-8", newline="\n") as out:
        json.dump(data, out, allow_nan=False, indent=2)
        out.write("\n")


def save_csv(path, table):
    table.to_csv(path, index=False, mode="x", float_format="%.17g", na_rep="NA")


def load_population(name, fixtures):
    candidates = LOCAL / (name + "_candidates.csv")
    predictions = LOCAL / (name + "_scores.csv")
    cases = pd.read_csv(candidates, dtype={"match": str})
    values = pd.read_csv(predictions, dtype={"match": str}, float_precision="round_trip")
    assert set(cases.match) == set(fixtures)
    assert cases.source.is_unique and not cases.duplicated(["match", "half", "frame"]).any()
    assert set(cases.outcome) <= {"shot", "pass"}
    assert cases.lead_frames.between(1, 100).all()
    assert cases["exact_owner"].isin([True, False]).all()
    assert (cases.metres.dropna() >= 0).all() and np.isfinite(cases.metres.dropna()).all()
    cases = cases.sort_values("source").set_index("source", verify_integrity=True)
    assert len(values) == len(cases) * 20 and set(values.seed) == set(SEEDS)
    assert set(values.world) == {"D", "CV"} and set(values.family) == set(READERS)
    assert values.q.dropna().between(0, 1).all()
    q = {}
    for key, group in values.groupby(["world", "family", "seed"]):
        group = group.set_index("source", verify_integrity=True).sort_index()
        pd.testing.assert_series_equal(group.match, cases.match)
        q[key] = group.q.to_numpy(dtype=float)
    assert len(q) == 20
    same_scores = np.isfinite(np.stack(list(q.values()))).all(axis=0)
    good = same_scores & cases.metres.notna().to_numpy()
    flow = []
    for mid in fixtures:
        selected = cases.match.eq(mid).to_numpy()
        flow.append(dict(match=mid, eligible_before_score_geometry=int(selected.sum()),
                         missing_geometry=int((selected & cases.metres.isna().to_numpy()).sum()),
                         missing_any_score=int((selected & ~same_scores).sum()),
                         included=int((selected & good).sum()),
                         shots=int((selected & good & cases.outcome.eq("shot").to_numpy()).sum())))
    if not all(r["included"] > 0 for r in flow):
        raise ValueError("A full fixture has no eligible observations")
    assert int(sum(r["included"] for r in flow)) == good.sum()
    return cases.loc[good].copy(), {k:v[good] for k,v in q.items()}, flow, {
        candidates.name: sha(candidates), predictions.name: sha(predictions)}


def design(metres, scores=None):
    columns = [metres, np.maximum(metres - 16.5, 0)]
    if scores is not None:
        columns.append(logit(np.clip(scores, 1e-12, 1 - 1e-12)))
    return np.column_stack(columns)


def fit_model(x, y, weight):
    mu = np.average(x, axis=0, weights=weight)
    sigma = np.sqrt(np.average((x - mu) ** 2, axis=0, weights=weight))
    sigma[sigma < 1e-12] = 1
    z = np.column_stack([np.ones(len(y)), (x - mu)/sigma])
    penalty = np.eye(z.shape[1])
    penalty[0, 0] = 0
    beta = np.zeros(z.shape[1])
    beta[0] = logit(np.average(y, weights=weight))
    def loss(t):
        logodds = z @ t
        return float(np.dot(weight, np.logaddexp(0, logodds) - y * logodds) + .5*np.dot(t[1:],t[1:]))
    for iteration in range(50):
        p = expit(z @ beta)
        grad = z.T @ (weight*(p-y)) + penalty @ beta
        norm = np.max(np.abs(grad))
        if norm < 1e-8:
            break
        hessian = (z.T * (weight*p*(1-p))) @ z + penalty
        direction = np.linalg.solve(hessian, grad)
        step = 1.
        before = loss(beta)
        while loss(beta-step*direction) > before - 1e-4*step*np.dot(grad, direction) + 1e-13:
            step *= .5
            if step < 1e-9:
                raise RuntimeError("Logistic Newton step failed")
        beta -= step*direction
    else:
        raise RuntimeError("Logistic fit failed to converge")
    return dict(mean=mu.tolist(), sd=sigma.tolist(), beta=beta.tolist(), iterations=iteration,
                regularized_loss=loss(beta), max_abs_gradient=float(norm))


def calibration_data(plan, expanded):
    fixtures = list(plan["calibration_matches"])
    cases, q, flow, inputs = load_population("calibration", fixtures)
    if expanded:
        extra_plan = load_json(HERE/"expanded_protocol.json")
        assert extra_plan["prior"] == sha(HERE/"protocol.json")
        more = extra_plan["calibration_extra_matches"]
        assert not set(more).intersection(fixtures + plan["assessment_matches"])
        other_cases, other_q, counts, hashes = load_population("dev12", more)
        assert not cases.index.intersection(other_cases.index).size
        cases = pd.concat([cases, other_cases], verify_integrity=True)
        q = {key:np.concatenate((value, other_q[key])) for key,value in q.items()}
        flow += counts
        inputs.update(hashes)
        fixtures.extend(more)
    return cases, q, flow, inputs, fixtures


def fit(plan, expanded=False):
    cases, q, flow, inputs, fixtures = calibration_data(plan, expanded)
    assert set(fixtures).isdisjoint(plan["assessment_matches"])
    y = cases.outcome.eq("shot").to_numpy(dtype=float)
    if y.min() == y.max():
        raise ValueError("Calibration set lacks both classes")
    weight = len(y) / (len(fixtures) * cases.groupby("match")["match"].transform("size"))
    weight = weight.to_numpy(dtype=float)
    assert np.isclose(weight.sum(), len(y))
    m = cases.metres.to_numpy(dtype=float)
    fitted = {"G": fit_model(design(m), y, weight)}
    for (world, reader, seed), scores in sorted(q.items()):
        fitted[f"{world}/{reader}/{seed}"] = fit_model(design(m, scores), y, weight)
    out = (HERE/"expanded" if expanded else HERE) / "fit"
    out.mkdir(parents=True,exist_ok=False)
    save_csv(out/"support.csv", pd.DataFrame(flow))
    save_json(out/"models.json", dict(protocol=sha(HERE/"protocol.json"), script=sha(Path(__file__)),
              split="calibration+dev12" if expanded else "calibration", fixtures=fixtures,
              expanded_protocol=sha(HERE/"expanded_protocol.json") if expanded else None,
              common_rows=len(y), source_digest=source_digest(cases),
              inputs=inputs, models=fitted))
    print("Fitted and sealed", len(fitted), "models for", len(y), "possessions,", int(y.sum()), "shots")


def source_digest(cases):
    return hashlib.sha256(np.asarray(cases.index, dtype="<i8").tobytes()).hexdigest()


def linear_predictor(model, x):
    return model["beta"][0] + ((x-np.asarray(model["mean"]))/np.asarray(model["sd"])) @ np.asarray(model["beta"][1:])


def metrics(s, y):
    if len(y) == 0:
        return dict.fromkeys(METRICS, np.nan)
    p = expit(s)
    bias = p.mean() - y.mean()
    k = int(y.sum())
    auc = (rankdata(s)[y].sum() - k*(k+1)/2)/(k*(len(y)-k)) if 0 < k < len(y) else np.nan
    return dict(logloss=np.mean(np.logaddexp(0,s)-s*y), brier=np.mean((p-y)**2),
                auc=auc, bias=bias, abs_bias=abs(bias))


def evaluate(plan, expanded=False):
    work = HERE/"expanded" if expanded else HERE
    model_file = work/"fit/models.json"
    frozen = load_json(model_file)
    assert frozen["protocol"] == sha(HERE/"protocol.json") and frozen["script"] == sha(Path(__file__))
    for name, digest in frozen["inputs"].items():
        assert sha(LOCAL/name) == digest
    if expanded:
        assert frozen["expanded_protocol"] == sha(HERE/"expanded_protocol.json")
    train_indices = set()
    for name in frozen["inputs"]:
        if name.endswith("_candidates.csv"):
            train_indices.update(pd.read_csv(LOCAL/name, usecols=["source"]).source.tolist())
    cases, q, flow, inputs = load_population("test", plan["assessment_matches"])
    assert not set(train_indices).intersection(cases.index)
    assert not set(cases.match).intersection(frozen["fixtures"])
    assert len(cases)==690 and cases.outcome.eq("shot").sum()==27
    metres = cases.metres.to_numpy()
    y = cases.outcome.eq("shot").to_numpy()
    strata = {"all": np.ones(len(cases), dtype=bool), "more_than_2s": cases.lead_frames.gt(20).to_numpy(),
              "exact_owner": cases.exact_owner.to_numpy(dtype=bool)}
    geometry = linear_predictor(frozen["models"]["G"], design(metres))
    rows = []
    for reader in READERS:
        for seed in SEEDS:
            estimates = {"G":geometry}
            for world in ("CV", "D"):
                model = frozen["models"][f"{world}/{reader}/{seed}"]
                estimates["G+"+world] = linear_predictor(model, design(metres, q[world,reader,seed]))
            for mid in plan["assessment_matches"]:
                belongs = cases.match.eq(mid).to_numpy()
                for stratum, available in strata.items():
                    use = belongs & available
                    for arm, log_odds in estimates.items():
                        rows.append(dict(match=mid, reader=reader, seed=seed, stratum=stratum, arm=arm,
                            n=int(use.sum()), shots=int(y[use].sum()), **metrics(log_odds[use], y[use])))
    f = pd.DataFrame(rows)
    keys = ["match","reader","seed","stratum"]
    comparisons = []
    for a,b in (("G+D","G"),("G+CV","G"),("G+D","G+CV")):
        left = f.loc[f.arm.eq(a)].set_index(keys)
        right = f.loc[f.arm.eq(b)].set_index(keys)
        delta = (left[list(METRICS)] - right[list(METRICS)]).assign(contrast=a+" minus "+b)
        comparisons.append(delta.reset_index())
    diffs = pd.concat(comparisons,ignore_index=True)
    def aggregate(table, field):
        group = table.groupby(["reader","seed","stratum",field])[list(METRICS)]
        by_seed = group.mean().where(group.count().eq(4)).reset_index()
        result = by_seed.groupby(["stratum","reader",field])[list(METRICS)].agg(["mean","std","count"])
        result.columns = ["_".join(t) for t in result.columns]
        return by_seed, result.reset_index()
    seeds, summary = aggregate(f, "arm")
    paired_seeds, paired_summary = aggregate(diffs, "contrast")
    out = work/"results"
    out.mkdir(exist_ok=False)
    for name, table in (("support",pd.DataFrame(flow)),("fixtures",f),("paired_fixtures",diffs),
                       ("seeds",seeds),("summary",summary),("paired_seeds",paired_seeds),("paired_summary",paired_summary)):
        save_csv(out/(name+".csv"),table)
    save_json(out/"receipt.json",dict(protocol=sha(HERE/"protocol.json"), models=sha(model_file), inputs=inputs,
              test_source_digest=source_digest(cases), train_test_source_overlap=0,
              files={path.name:sha(path) for path in sorted(out.glob("*.csv"))}))
    print(paired_summary.query("stratum=='all'").to_string(index=False))

