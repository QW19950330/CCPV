"""Compare prespecified geometry and motion controls on archived possession endings.

Run fit for both schemes before evaluate. Individual possession records remain on the local research drive.
"""
from pathlib import Path
import argparse
import importlib.util
import sys
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from scipy.special import logit

sys.dont_write_bytecode = True
import distance_models as prior
HERE = None  # geometry-model output directory
V97 = None   # freshly fitted distance-model output directory
INPUT_DIRS = {} # keys "geometry" and "hold" point to input directories supplied by the runner
METRICS = list(prior.METRICS)
WORLDS = ["HOLD", "CV", "D"]
CONTRASTS = [("A","G"), ("A+HOLD","A"), ("A+CV","A"), ("A+D","A"),
             ("A+CV","A+HOLD"), ("A+D","A+HOLD"), ("A+D","A+CV")]
SCHEMES = {"four":["calibration"], "sixteen":["calibration","dev12"]}


def utc():
    return datetime.now(timezone.utc).isoformat()


def old_frozen(scheme):
    prefix = V97 if scheme == "four" else V97 / "expanded"
    model_file = prefix / "fit/models.json"
    return prior.load_json(model_file)


def load_split(split):
    plan = prior.load_json(V97 / "protocol.json")
    groups = {"calibration":plan["calibration_matches"], "test":plan["assessment_matches"],
              "dev12":prior.load_json(V97 / "expanded_protocol.json")["calibration_extra_matches"]}
    cases, scores, _, pins = prior.load_population(split, groups[split])
    expected = old_frozen("sixteen")["inputs"] if split != "test" else prior.load_json(V97/"results/receipt.json")["inputs"]
    assert all(expected[name] == digest for name,digest in pins.items())
    total = pd.read_csv(prior.LOCAL/(split+"_candidates.csv"), usecols=["source","match","half","frame"], dtype={"match":str})
    geo_path = INPUT_DIRS["geometry"] / (split+".csv")
    hold_path = INPUT_DIRS["hold"] / (split+".csv")
    geometry = pd.read_csv(geo_path, dtype={"match":str}, float_precision="round_trip").set_index("source", verify_integrity=True)
    assert set(geometry.index) == set(total.source)
    match_keys = ["match","half","frame"]
    pd.testing.assert_frame_equal(total.set_index("source")[match_keys].sort_index(),geometry[match_keys].sort_index(),check_dtype=False)
    a = geometry.loc[cases.index]
    np.testing.assert_allclose(a.metres,cases.metres,rtol=0,atol=5e-10)
    assert np.isfinite(a.angle_rad).all() and a.angle_rad.between(0,np.pi).all()
    cases["angle_rad"] = a.angle_rad
    hold = pd.read_csv(hold_path,dtype={"match":str},float_precision="round_trip")
    assert set(hold.family) == set(prior.READERS) and set(hold.seed) == set(prior.SEEDS)
    assert len(hold) == len(total)*len(prior.READERS)*len(prior.SEEDS)
    for (reader,seed), block in hold.groupby(["family","seed"]):
        block=block.set_index("source", verify_integrity=True)
        assert set(block.index) == set(total.source)
        pd.testing.assert_series_equal(block.match.sort_index(),total.set_index("source").match.sort_index())
        values=block.loc[cases.index,"q"]
        assert np.isfinite(values).all() and values.between(0,1).all()
        scores[("HOLD",reader,int(seed))]=values.to_numpy()
    for label,path in (("geometry", geo_path),("hold", hold_path)):
        pins["controls/" + label + "/" + path.name] = prior.sha(path)
    return cases,scores,pins


def features(cases, arm, score=None):
    x=prior.design(cases.metres.to_numpy())
    if arm != "G":
        x=np.column_stack((x,cases.angle_rad))
    if score is not None:
        x=np.column_stack((x,logit(np.clip(score,1e-12,1-1e-12))))
    return x


def fit():
    sources={k:load_split(k) for k in ("calibration","dev12")}
    bundle={}
    for scheme,parts in SCHEMES.items():
        cases=pd.concat([sources[p][0] for p in parts],verify_integrity=True)
        frozen=old_frozen(scheme)
        assert prior.source_digest(cases)==frozen["source_digest"]
        n=len(cases)
        weights=(n/(len(frozen["fixtures"])*cases.groupby("match").match.transform("size"))).to_numpy()
        y=cases.outcome.eq("shot").to_numpy(dtype=float)
        models={arm:prior.fit_model(features(cases,arm),y,weights) for arm in ["G","A"]}
        for k in ["mean","sd","beta"]:
            np.testing.assert_allclose(models["G"][k],frozen["models"]["G"][k],rtol=0,atol=1e-12)
        for (world,reader,seed) in sorted(sources[parts[0]][1]):
            score=np.concatenate([sources[p][1][world,reader,seed] for p in parts])
            models[f"{world}/{reader}/{seed}"]=prior.fit_model(features(cases,"A+"+world,score),y,weights)
        assert len(models)==32
        bundle[scheme]=dict(n=n,shots=int(y.sum()),fixtures=frozen["fixtures"],source_digest=prior.source_digest(cases),
                            inputs={k:v for p in parts for k,v in sources[p][2].items()},models=models)
    prior.save_json(HERE/"models.json",dict(frozen_utc=utc(),code=prior.sha(Path(__file__)),protocol=prior.sha(HERE/"protocol.json"),schemes=bundle))
    print("Sealed both calibration schemes",[(k,v["n"],v["shots"]) for k,v in bundle.items()])


def evaluate():
    frozen=prior.load_json(HERE/"models.json")
    assert frozen["code"]==prior.sha(Path(__file__)) and frozen["protocol"]==prior.sha(HERE/"protocol.json")
    cases,scores,test_pins=load_split("test")
    assert prior.source_digest(cases)==prior.load_json(V97/"results/receipt.json")["test_source_digest"]
    assert len(cases)==690 and cases.outcome.eq("shot").sum()==27
    y=cases.outcome.eq("shot").to_numpy()
    strata={"all":np.ones(len(cases),bool), "more_than_2s":cases.lead_frames.gt(20).to_numpy(), "exact_owner":cases.exact_owner.to_numpy(bool)}
    outcomes=[]
    for scheme,record in frozen["schemes"].items():
        for name,digest in record["inputs"].items():
            if name.startswith("controls/"):
                _,label,filename = name.split("/")
                source = INPUT_DIRS[label] / filename
            else:
                source = prior.LOCAL / name
            assert prior.sha(source) == digest
        assert set(cases.match).isdisjoint(record["fixtures"])
        models=record["models"]
        geometry={arm:prior.linear_predictor(models[arm],features(cases,arm)) for arm in ("G","A")}
        for reader in prior.READERS:
            for seed in prior.SEEDS:
                est=dict(geometry)
                for world in WORLDS:
                    arm="A+"+world
                    est[arm]=prior.linear_predictor(models[f"{world}/{reader}/{seed}"],features(cases,arm,scores[world,reader,seed]))
                for match in sorted(cases.match.unique()):
                    for stratum,sel in strata.items():
                        ix=sel & cases.match.eq(match).to_numpy()
                        for arm,odds in est.items():
                            outcomes.append(dict(scheme=scheme,match=match,reader=reader,seed=seed,stratum=stratum,arm=arm,
                                      n=int(ix.sum()),shots=int(y[ix].sum()),**prior.metrics(odds[ix],y[ix])))
    f=pd.DataFrame(outcomes)
    keys=["scheme","match","reader","seed","stratum"]
    paired=[]
    for arm,control in CONTRASTS:
        difference=f[f.arm==arm].set_index(keys)[METRICS]-f[f.arm==control].set_index(keys)[METRICS]
        paired.append(difference.assign(contrast=arm+" minus "+control).reset_index())
    diff=pd.concat(paired,ignore_index=True)
    result={"fixtures":f,"paired_fixtures":diff}
    for table,key,prefix in [(f,"arm",""),(diff,"contrast","paired_")]:
        group=table.groupby(["scheme","reader","seed","stratum",key])[METRICS]
        by_seed=group.mean().where(group.count().eq(4)).reset_index()
        summary=by_seed.groupby(["scheme","reader","stratum",key])[METRICS].agg(["mean","std","count"])
        summary.columns=["_".join(k) for k in summary.columns]
        result[prefix+"seeds"]=by_seed
        result[prefix+"summary"]=summary.reset_index()
    folder=HERE/"results"
    folder.mkdir(exist_ok=False)
    for name,t in result.items():
        prior.save_csv(folder/(name+".csv"),t)
    prior.save_json(folder/"receipt.json",dict(finished_utc=utc(),models=prior.sha(HERE/"models.json"),
                evaluation_inputs=test_pins,files={name:prior.sha(folder/(name+".csv")) for name in result},
                source_digest=prior.source_digest(cases),train_test_fixture_overlap=0,independent_test_matches=4))
    print(result["paired_summary"].query("stratum=='all' and reader=='CV-DirectWith'")[["scheme","contrast","logloss_mean","logloss_std"]].to_string(index=False))

