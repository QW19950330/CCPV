"""Recompute stationary future paths and frozen shot scores from prefix histories."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import zipfile

for thread_option in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[thread_option] = "1"

import numpy as np
import pandas as pd

import distance_models as stats
import raw36_adapter as feature

FAMILIES = {"CV-DirectWith":"CV_Direct_WithEarlyBCE", "D-DirectWith":"D_Direct_WithEarlyBCE"}
CONFIG = Path(__file__).with_name("frozen_checks.json")


def load_heads(path, plan):
    assert stats.sha(path) == plan["clean_weights"]
    heads = {}
    with zipfile.ZipFile(path) as archive:
        spec = plan["clean_weights_manifest"]
        blob = archive.read(spec["member"])
        assert hashlib.sha256(blob).hexdigest() == spec["sha256"]
        for rec in json.loads(blob)["files"]:
            if rec.get("semantics") != "Direct" or rec.get("arm") not in FAMILIES.values():
                continue
            key = rec["arm"], rec["seed"], rec["fold"]
            assert key not in heads
            raw = archive.read(rec["clean_payload"])
            assert hashlib.sha256(raw).hexdigest() == rec["export_sha256"]
            with np.load(io.BytesIO(raw), allow_pickle=False) as z:
                cp = {name:z[name] for name in z.files}
            assert int(cp["raw_dimension"]) == 36 and int(cp["parameter_count"]) == 602
            heads[key] = cp
    assert set(heads) == {(fam, seed, fold) for fam in FAMILIES.values() for seed in range(5) for fold in range(6)}
    return heads


def stationary_features(batch):
    ctx = feature.prepare_prefix_batch(batch)
    history, valid = batch["history_states"], batch["history_valid"]
    n, t, entities, _ = history.shape
    last_index = np.where(valid, np.arange(t)[None, :, None], -1).max(1)
    present = last_index >= 0
    prior = history[np.arange(n)[:, None], np.maximum(last_index, 0), np.arange(entities)[None, :]].copy()
    prior[~present] = 0
    age = (np.float32(t-1) - np.maximum(last_index, 0).astype(np.float32)) / np.float32(10.0)
    anchor = prior.copy()
    anchor[..., :2] = prior[..., :2] + age[..., None] * prior[..., 2:]
    anchor[~present] = 0
    assert np.array_equal(present, ctx["history_seen"])
    ok = ctx["initial_eligible"]
    states = np.full((n,20,entities,4), np.nan, dtype=np.float32)
    support = np.zeros((n,20,entities), dtype=bool)
    anchor[..., 2:] = 0
    states[ok] = np.broadcast_to(anchor[ok,None], (int(ok.sum()),20,entities,4))
    support[ok] = np.broadcast_to(present[ok,None], (int(ok.sum()),20,entities))
    steps = np.where(ok,20,0).astype(np.int64)
    raw, complete = feature.M.path_features(history, valid, batch["entity_ids"], states, support, steps,
                                           ctx["X0"], ctx["old_CV8"])
    return raw, complete & ctx["prefix_supported"]


def main(args):
    plan = stats.load_json(CONFIG)
    heads = load_heads(args.weights, plan)
    args.output.mkdir(parents=True, exist_ok=False)
    verified = {}
    for name in ("calibration", "dev12", "test"):
        inputs = plan["splits"][name]
        prefix = getattr(args, name)
        candidates = args.candidates / f"{name}_candidates.csv"
        assert stats.sha(prefix) == inputs["prefix"] and stats.sha(candidates) == inputs["candidates"]
        members = pd.read_csv(candidates, usecols=["source","match"], dtype={"match":str}).set_index("source", verify_integrity=True)
        with np.load(prefix, allow_pickle=False) as z:
            a = {k:z[k] for k in feature.PREFIX_KEYS}
        present = np.isin(a["source_indices"], members.index)
        assert int(present.sum()) == len(members)
        output = []
        for start in range(0, len(present), 32):
            stop = min(start+32, len(present))
            selected = np.flatnonzero(present[start:stop])
            if not len(selected):
                continue
            batch = {k:(v if k == "teams" else v[start:stop]) for k,v in a.items()}
            raw, allowed = stationary_features(batch)
            for family, arm in FAMILIES.items():
                for seed in range(5):
                    q = np.full(len(raw), np.nan)
                    if allowed.any():
                        pairs = [feature.M.predict_direct(heads[arm,seed,fold], raw[allowed]) for fold in range(6)]
                        log_p, _ = feature.M.probability_mean(pairs)
                        q[allowed] = np.exp(log_p)
                    for j in selected:
                        source = int(batch["source_indices"][j])
                        match = batch["match_ids"][j].split(":")[-1]
                        assert members.loc[source, "match"] == match
                        output.append((source, match, family, seed, repr(float(q[j]))))
        output.sort(key=lambda row:(row[0], row[2], row[3]))
        target = args.output / f"{name}.csv"
        with target.open("x", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["source","match","family","seed","q"])
            writer.writerows(output)
        assert len(output) == len(members)*10 and stats.sha(target) == inputs["hold"]
        verified[name] = dict(rows=len(output), sha256=stats.sha(target))
        print(name, verified[name], flush=True)
    stats.save_json(args.output / "verification.json", dict(scores=verified, frozen_heads=len(heads), new_training_updates=0))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for split in ("calibration","dev12","test"):
        parser.add_argument("--"+split, type=Path, required=True, help="Private prepared prefix NPZ for this split")
    parser.add_argument("--weights", type=Path, required=True, help="Published clean inference weight ZIP")
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
