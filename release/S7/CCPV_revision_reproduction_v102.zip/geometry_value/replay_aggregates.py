"""Offline equal-fixture contrasts from published aggregate cells, using only the standard library."""
import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
FIXTURES = ('A', 'B', 'C', 'D')
READERS = ('CV-DirectWith', 'D-DirectWith')
SCHEMES = ('four', 'sixteen')
SEEDS = range(5)
METRICS = ('logloss', 'brier', 'auc', 'bias', 'abs_bias')
CONTRASTS = {
    'distance': [('G+D', 'G'), ('G+CV', 'G'), ('G+D', 'G+CV')],
    'geometry_hold': [('A', 'G'), ('A+HOLD', 'A'), ('A+CV', 'A'), ('A+D', 'A'),
                      ('A+CV', 'A+HOLD'), ('A+D', 'A+HOLD'), ('A+D', 'A+CV')],
}


def read_fixture_metrics(path, expected):
    contents = path.read_bytes().replace(b'\r\n', b'\n')
    if hashlib.sha256(contents).hexdigest() != expected['fixture_table_sha256_lf']:
        raise ValueError('Fixture aggregate CSV differs from the verification copy.')
    cells, supports = {}, {}
    with path.open(encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            fixture = row['fixture']
            key = (row['comparison'], row['calibration'], row['reader'], int(row['seed']), fixture, row['arm'])
            values = {metric: float(row[metric]) for metric in METRICS}
            if key in cells or not all(map(math.isfinite, values.values())):
                raise ValueError('Duplicate fixture cell or missing metric.')
            cells[key] = values
            support = int(row['cases']), int(row['shots'])
            if supports.setdefault(fixture, support) != support:
                raise ValueError('Methods are on different outcome supports.')
    if tuple(sorted(supports)) != FIXTURES or tuple(map(sum, zip(*supports.values()))) != (690, 27):
        raise ValueError('Fixture denominators differ from the historical cohort.')
    if len(cells) != 640:
        raise ValueError('Expected 640 fixture–method cells.')
    return cells


def paired_statistics(cells):
    results = []
    for comparison, contrasts in CONTRASTS.items():
        for calibration, reader, (arm, control), metric in itertools.product(SCHEMES, READERS, contrasts, METRICS):
            by_seed = []
            for seed in SEEDS:
                differences = []
                for fixture in FIXTURES:
                    k = (comparison, calibration, reader, seed, fixture)
                    differences.append(cells[k + (arm,)][metric] - cells[k + (control,)][metric])
                by_seed.append(statistics.fmean(differences))
            results.append(dict(comparison=comparison, calibration=calibration, reader=reader,
                                contrast=f'{arm} minus {control}', metric=metric,
                                **{f'seed_{seed}': dx for seed, dx in enumerate(by_seed)},
                                mean=statistics.fmean(by_seed), sample_sd=statistics.stdev(by_seed),
                                negative_seeds=sum(dx < 0 for dx in by_seed),
                                zero_seeds=sum(dx == 0 for dx in by_seed),
                                positive_seeds=sum(dx > 0 for dx in by_seed)))
    return results


def main(out):
    checks = json.loads((ROOT/'aggregate/checks.json').read_text(encoding='utf-8'))
    cells = read_fixture_metrics(ROOT/'aggregate/fixture_metrics.csv', checks)
    results = paired_statistics(cells)
    for ref in checks['locked_CV_reader_deep_minus_hold']:
        row, = (r for r in results if r['reader'] == 'CV-DirectWith' and r['calibration'] == ref['calibration']
                and r['contrast'] == 'A+D minus A+HOLD' and r['metric'] == 'logloss')
        if not (abs(row['mean'] - ref['logloss_mean']) < 1e-14 and abs(row['sample_sd'] - ref['logloss_sd']) < 1e-14):
            raise ValueError('Historical primary comparison failed to replicate.')
        scores = ', '.join(f'{row[f"seed_{seed}"]:+.9f}' for seed in SEEDS)
        print(f"{row['calibration']} calibration fixtures, A+D minus A+HOLD log loss "
              f"{row['mean']:+.9f} +/- {row['sample_sd']:.9f}, {row['negative_seeds']}/5 lower, seeds [{scores}]")
    if out is not None:
        with out.open('x', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(results[0]), lineterminator='\n')
            writer.writeheader()
            writer.writerows(results)
    return results


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, help='New CSV for all 200 metric and contrast combinations')
    main(ap.parse_args().output)
