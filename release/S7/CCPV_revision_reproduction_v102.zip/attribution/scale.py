"""Audit link-scale sensitivity in previously computed two-actor coalition games."""
import csv
import math
import statistics
from collections import Counter, defaultdict


EPS = 1e-12
FIELDS = (
    "signed_Iq",
    "abs_Iq",
    "signed_C",
    "abs_C",
    "signed_R",
    "abs_R",
    "signed_L",
    "abs_L",
    "pct_abs_R_gt_C",
    "pct_sign_opposed",
)


def table(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream)


def save_table(path, rows):
    with path.open("x", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sign(x):
    return int(x > EPS) - int(x < -EPS)


def logit(p):
    return math.log(p) - math.log1p(-p)


def components(e, a, b, ab):
    assert all(0 < p < 1 for p in (e, a, b, ab))
    iq = (ab - a) - (b - e)
    uv = (a - e) * (b - e)
    curve = (1 - a - b) * uv / (e * (1 - e) + uv)
    residual = iq - curve
    ell = (logit(ab) - logit(a)) - (logit(b) - logit(e))
    odds_add = logit(a) + logit(b) - logit(e)
    p_add = 1.0 / (1.0 + math.exp(-odds_add))
    assert abs((ab - p_add) - residual) < 1e-14
    # Shapley A minus Shapley B is the difference of singleton values on either scale.
    order = int(a > b) - int(a < b)
    log_order = int(logit(a) > logit(b)) - int(logit(a) < logit(b))
    return (
        iq,
        curve,
        residual,
        ell,
        order,
        log_order,
        sign(a - b),
        sign(logit(a) - logit(b)),
    )


def summarize_fixture(key, rows):
    reader, reference, subset, seed, match = key
    columns = list(zip(*rows))
    out = dict(
        reader=reader,
        reference=reference,
        subset=subset,
        seed=seed,
        match_id=match,
        n=len(rows),
    )
    for name, col in zip(("Iq", "C", "R", "L"), columns[:4]):
        out["signed_" + name] = statistics.fmean(col)
        out["abs_" + name] = statistics.fmean(map(abs, col))
    flags = [(sign(x[0]), sign(x[3])) for x in rows]
    comparable = sum(a != 0 and b != 0 for a, b in flags)
    opposed = sum(a * b < 0 for a, b in flags)
    out.update(
        pct_abs_R_gt_C=100 * sum(abs(x[2]) > abs(x[1]) for x in rows) / len(rows),
        pct_sign_opposed=100 * opposed / comparable if comparable else None,
        comparable=comparable,
        opposed=opposed,
        Iq_ties=sum(a == 0 for a, b in flags),
        L_ties=sum(b == 0 for a, b in flags),
        actor_order_reversal=sum(x[4] * x[5] < 0 for x in rows),
        actor_order_tie_disagreement=sum(x[4] != x[5] for x in rows),
        actor_order_tol_reversal=sum(x[6] * x[7] < 0 for x in rows),
        actor_order_tol_tie_disagreement=sum(x[6] != x[7] for x in rows),
    )
    return out


def grouped(rows, keys):
    parts = defaultdict(list)
    for row in rows:
        parts[tuple(row[k] for k in keys)].append(row)
    return [(dict(zip(keys, k)), v) for k, v in sorted(parts.items())]


def fixture_from_cases(src, roles_path):
    """Recompute fixture rows from local coalition values and independently recorded t0 roles."""
    roles = {}
    for row in table(roles_path):
        if row["cohort"].lower() == "train" and row["common680"] == "True":
            assert row["row"] not in roles
            roles[row["row"]] = row
    assert len(roles) == 680
    assert Counter(row["role_group"] for row in roles.values()) == {
        "CONFIRMED_OWN_NONPOSSESSOR_PAIR": 70,
        "KNOWN_NOT_OWN_NONPOSSESSOR_PAIR": 324,
        "UNKNOWN_PAIR_CONTEXT": 286,
    }
    cases = defaultdict(list)
    seen = set()
    max_source_diff = 0.0
    for row in table(src):
        if (
            row["world_arm"] != "D_coupled_ar"
            or row["value_family"]
            not in ("CV_Direct_WithEarlyBCE", "D_Direct_WithEarlyBCE")
            or row["common_reference_intersection"] != "True"
        ):
            continue
        reader, seed, idx = row["value_family"], int(row["seed"]), row["scene_index"]
        role = roles[idx]
        match = row["match_id"].removeprefix("skillcorner:")
        assert (
            match,
            row["source_index"],
            row["actor_A_source_id"],
            row["actor_B_source_id"],
        ) == (role["match_id"], role["source_index"], role["A_id"], role["B_id"])
        assert (reader, seed, idx) not in seen and seed in range(5)
        seen.add((reader, seed, idx))
        for ref in ("old", "new"):
            e, a, b, ab = [
                float(row[f"{ref}_q_{col}"]) for col in ("empty", "A", "B", "AB")
            ]
            data = components(e, a, b, ab)
            max_source_diff = max(
                max_source_diff,
                abs(data[0] - float(row[f"{ref}_interaction_difference"])),
            )
            assert (
                abs((a - b) - (float(row[f"{ref}_phi_A"]) - float(row[f"{ref}_phi_B"])))
                < 1e-14
            )
            cases[reader, ref, "all680", seed, match].append(data)
            if role["role_group"] == "CONFIRMED_OWN_NONPOSSESSOR_PAIR":
                cases[reader, ref, "offball70", seed, match].append(data)
    assert len(seen) == 2 * 5 * 680 and max_source_diff < 1e-14
    fixtures = [summarize_fixture(k, v) for k, v in sorted(cases.items())]
    return fixtures, {
        "unique_reader_seed_scene": len(seen),
        "max_interaction_discrepancy": max_source_diff,
        "role_counts": dict(Counter(r["role_group"] for r in roles.values())),
    }


def aggregate(fixtures):
    seeds = []
    keys = ["reader", "reference", "subset"]
    for key, fixture_rows in grouped(fixtures, keys + ["seed"]):
        assert len(fixture_rows) == 12
        assert sum(r["n"] for r in fixture_rows) == (
            680 if key["subset"] == "all680" else 70
        )
        seed = dict(
            key, n=sum(r["n"] for r in fixture_rows), n_matches=len(fixture_rows)
        )
        for field in FIELDS:
            values = [r[field] for r in fixture_rows if r[field] is not None]
            seed[field] = statistics.fmean(values) if values else None
            if field == "pct_sign_opposed":
                seed["matches_with_comparable"] = len(values)
        seeds.append(seed)
    summary = []
    for key, seed_rows in grouped(seeds, keys):
        assert len(seed_rows) == 5
        record = dict(
            key,
            n_seeds=5,
            windows_per_seed=seed_rows[0]["n"],
            matches_per_seed=seed_rows[0]["n_matches"],
        )
        for field in FIELDS:
            values = [r[field] for r in seed_rows if r[field] is not None]
            record[field + "_mean"] = statistics.fmean(values) if values else None
            record[field + "_sd"] = (
                statistics.stdev(values) if len(values) > 1 else None
            )
        summary.append(record)
    return seeds, summary


def match_influence(fixtures, summary):
    groups = defaultdict(lambda: defaultdict(list))
    for row in fixtures:
        groups[tuple(row[k] for k in ("reader", "reference", "subset"))][
            row["match_id"]
        ].append(row)
    main_results = {
        tuple(row[k] for k in ("reader", "reference", "subset")): row for row in summary
    }
    output = []
    for group, matches in sorted(groups.items()):
        assert len(matches) == 12
        by_match = {}
        for match_id, runs in matches.items():
            assert sorted(int(row["seed"]) for row in runs) == list(range(5))
            # Every fixture/seed here has at least one sign-resolved comparison.
            assert all(int(row["comparable"]) > 0 for row in runs)
            by_match[match_id] = statistics.fmean(
                float(row["pct_sign_opposed"]) for row in runs
            )
        assert math.isclose(
            statistics.fmean(by_match.values()),
            float(main_results[group]["pct_sign_opposed_mean"]),
            abs_tol=1e-13,
        )
        for omitted, value in by_match.items():
            others = [v for k, v in by_match.items() if k != omitted]
            output.append(
                {
                    **dict(zip(("reader", "reference", "subset"), group)),
                    "omitted_match_id": omitted,
                    "rate_in_omitted_match_pct": value,
                    "other_eleven_rate_pct": statistics.fmean(others),
                    "eligible_windows_in_omitted_match": int(matches[omitted][0]["n"]),
                }
            )
    assert len(output) == 96
    return output
