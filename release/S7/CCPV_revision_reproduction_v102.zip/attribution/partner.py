"""Aggregate complete paired windows within match and then use equal fixture/seed weights."""
import math
from collections import Counter
import numpy as np
from scale import table

THRESHOLDS = {"raw": 1e-12, "1e-6": 1e-6, "1e-5": 1e-5}
MEASURES = (
    "phi_AB",
    "phi_AC",
    "abs_phi_AB",
    "abs_phi_AC",
    "delta",
    "abs_delta",
    "i_AB",
    "i_AC",
    "interaction_shift",
)


def avg(vals):
    return float(np.mean(vals)) if vals else None


def sign(value, eps):
    return 1 if value > eps else -1 if value < -eps else 0


def fixture_record(rows, scope, match, seed, reader):
    kept = [r for r in rows if r["status"] == "PAIRED_COMPLETE"]
    rec = dict(
        scope=scope,
        reader=reader,
        seed=seed,
        match_id=match,
        planned=len(rows),
        eligible=sum(bool(r["C_id"]) for r in rows),
        pairs=len(kept),
    )
    for k in MEASURES:
        rec[k] = avg([r[k] for r in kept])
    for name, threshold in THRESHOLDS.items():
        codes = [
            (sign(r["phi_AB"], threshold), sign(r["phi_AC"], threshold)) for r in kept
        ]
        comparable = sum(a * b != 0 for a, b in codes)
        opp = sum(a * b < 0 for a, b in codes)
        counts = {
            "opposite": opp,
            "comparable": comparable,
            "both_tie": sum(a == 0 and b == 0 for a, b in codes),
            "AB_tie_only": sum(a == 0 and b != 0 for a, b in codes),
            "AC_tie_only": sum(a != 0 and b == 0 for a, b in codes),
        }
        for key, val in counts.items():
            rec[name + "_" + key] = val
        rec[name + "_rate_all"] = opp / len(codes) if codes else None
        rec[name + "_rate_comparable"] = opp / comparable if comparable else None
        assert comparable + sum(
            counts[k] for k in ("both_tie", "AB_tie_only", "AC_tie_only")
        ) == len(kept)
    return rec


def fixture_from_cases(scene_path):
    source = list(table(scene_path))
    assert len(source) == 700
    unique = {(r["row"], r["seed"], r["reader"]) for r in source}
    assert len(unique) == 700
    all_matches = sorted({r["match_id"] for r in source})
    assert len(all_matches) == 12
    readers = sorted({r["reader"] for r in source})
    assert len(readers) == 2
    masks = {}
    worst = 0
    max_phi_error = 0.0
    for r in source:
        r["seed"] = int(r["seed"])
        key = (r["row"], r["seed"])
        valid = r["status"] == "PAIRED_COMPLETE"
        if key in masks:
            assert masks[key] == valid
        masks[key] = valid
        for k in ("q0", "qA", "qB", "qAB", "qC", "qAC", "phi_AB", "phi_AC", "delta"):
            r[k] = float(r[k]) if r[k] else None
        assert math.isfinite(r["phi_AB"])

        def allocation(other, joint):
            return ((r["qA"] - r["q0"]) + (r[joint] - r[other])) / 2.0

        phi_ab = allocation("qB", "qAB")
        max_phi_error = max(max_phi_error, abs(phi_ab - r["phi_AB"]))
        if valid:
            phi_ac = allocation("qC", "qAC")
            max_phi_error = max(
                max_phi_error,
                abs(phi_ac - r["phi_AC"]),
                abs(phi_ac - phi_ab - r["delta"]),
            )

        if valid:
            r["abs_phi_AB"] = abs(r["phi_AB"])
            r["abs_phi_AC"] = abs(r["phi_AC"])
            r["abs_delta"] = abs(r["delta"])
            r["i_AB"] = r["qAB"] - r["qA"] - r["qB"] + r["q0"]
            r["i_AC"] = r["qAC"] - r["qA"] - r["qC"] + r["q0"]
            r["interaction_shift"] = r["i_AC"] - r["i_AB"]
            worst = max(worst, abs(r["delta"] - 0.5 * r["interaction_shift"]))
    assert worst < 1e-14 and max_phi_error < 1e-14
    common = {r["row"] for r in source if all(masks[r["row"], s] for s in range(5))}
    fixtures = []
    counts = []
    for reader in readers:
        for scope in ("primary_per_seed", "diagnostic_completed_all_5"):
            for seed in range(5):
                rows = [
                    r
                    for r in source
                    if r["reader"] == reader
                    and r["seed"] == seed
                    and (scope == "primary_per_seed" or r["row"] in common)
                ]
                fixtures.extend(
                    fixture_record(
                        [r for r in rows if r["match_id"] == fixture],
                        scope,
                        fixture,
                        seed,
                        reader,
                    )
                    for fixture in all_matches
                )
        statuses = Counter(
            (r["seed"], r["status"], r["status_C"], r["status_AC"])
            for r in source
            if r["reader"] == reader
        )
        for (seed, status, c_status, ac_status), count in sorted(statuses.items()):
            counts.append(
                dict(
                    reader=reader,
                    seed=seed,
                    status=status,
                    C_path=c_status,
                    AC_path=ac_status,
                    windows=count,
                )
            )
    return (
        fixtures,
        counts,
        {
            "reader_seed_scene_rows": len(source),
            "windows_complete_all_five": len(common),
            "max_delta_minus_half_interaction_shift": worst,
            "max_allocation_residual": max_phi_error,
        },
    )


def aggregate(fixtures):
    seeds = []
    summary = []
    readers = sorted({r["reader"] for r in fixtures})
    rate_keys = [
        q + "_" + k for q in THRESHOLDS for k in ("rate_all", "rate_comparable")
    ]
    count_keys = ["planned", "eligible", "pairs"] + [
        q + "_" + k
        for q in THRESHOLDS
        for k in ("opposite", "comparable", "both_tie", "AB_tie_only", "AC_tie_only")
    ]
    for reader in readers:
        for scope in ("primary_per_seed", "diagnostic_completed_all_5"):
            for s in range(5):
                ff = [
                    r
                    for r in fixtures
                    if r["reader"] == reader and r["scope"] == scope and r["seed"] == s
                ]
                assert len(ff) == 12 and len({r["match_id"] for r in ff}) == 12
                out = dict(
                    scope=scope,
                    reader=reader,
                    seed=s,
                    planned_fixtures=12,
                    supported_fixtures=sum(x["pairs"] > 0 for x in ff),
                )
                for k in count_keys:
                    out[k] = sum(x[k] for x in ff)
                for k in (*MEASURES, *rate_keys):
                    valid = [x[k] for x in ff if x[k] is not None]
                    out[k] = avg(valid)
                    if k.endswith("_comparable"):
                        out[k + "_nfixtures"] = len(valid)
                seeds.append(out)
            ss = [r for r in seeds if r["scope"] == scope and r["reader"] == reader]
            for k in (*MEASURES, *rate_keys):
                vals = [r[k] for r in ss if r[k] is not None]
                support = [r.get(k + "_nfixtures", r["supported_fixtures"]) for r in ss]
                summary.append(
                    dict(
                        scope=scope,
                        reader=reader,
                        measure=k,
                        mean_equal_fixtures_then_seeds=avg(vals),
                        sd_across_seeds_ddof1=float(np.std(vals, ddof=1))
                        if len(vals) > 1
                        else None,
                        nseeds=len(vals),
                        min_contributing_fixtures=min(support),
                        max_contributing_fixtures=max(support),
                        all_12_every_seed=all(v == 12 for v in support),
                    )
                )
    return seeds, summary
