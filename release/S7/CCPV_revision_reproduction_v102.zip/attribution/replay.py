"""Reproduce the link-scale, leave-one-match-out and replacement-partner tables."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import tempfile

import partner
import scale


HERE = Path(__file__).resolve().parent
REFERENCE = HERE / "aggregate_inputs"
LOCAL_INPUTS = {
    "coalitions": "afa99e0dfe6043d79ae7231d8177d8bfdf62684d6fca36f8261830e23cba7da6",
    "roles": "ecc5456f6816c94c8108ee977423ede33e8d31ed8f8fe8be212318c8362dcfbb",
    "partner_cases": "c41e014e8946d22c3ace1b9616f05552b216bb45371a13a8ffcc5ee15e35de8a",
}


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_fixture(folder):
    with (REFERENCE / folder / "fixture.csv").open(
        encoding="utf-8-sig", newline=""
    ) as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for k, value in row.items():
            if k in {"reader", "reference", "subset", "scope", "match_id"}:
                continue
            if not value:
                row[k] = None
            elif value.lstrip("-").isdigit():
                row[k] = int(value)
            else:
                row[k] = float(value)
    return rows


def write_and_check(out, family, name, records):
    destination = out / family / (name + ".csv")
    destination.parent.mkdir(exist_ok=True)
    encoding = "utf-8-sig" if family == "partner" else "utf-8"
    with destination.open("x", newline="", encoding=encoding) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    reference = REFERENCE / family / destination.name
    if sha(destination) != sha(reference):
        raise ValueError(f"Reference table mismatch: {family}/{destination.name}")
    return {"data_rows": len(records), "sha256": sha(destination)}


def run(args, out):
    checks = json.loads((HERE / "reference_hashes.json").read_bytes())
    for name, expected in checks.items():
        if sha(REFERENCE / name) != expected:
            raise ValueError(f"Unexpected aggregate input: {name}")
    local = args.mode == "local-values"
    diagnostics = {}
    if local:
        for key, expected in LOCAL_INPUTS.items():
            if sha(getattr(args, key)) != expected:
                raise ValueError(f"Frozen upstream input mismatch: {key}")
        scales, diagnostics["scale"] = scale.fixture_from_cases(
            args.coalitions, args.roles
        )
        partners, statuses, diagnostics["partner"] = partner.fixture_from_cases(
            args.partner_cases
        )
    else:
        scales, partners = read_fixture("scale"), read_fixture("partner")

    reproduced = {}
    if local:
        reproduced["scale/fixture"] = write_and_check(out, "scale", "fixture", scales)
        reproduced["partner/fixture"] = write_and_check(
            out, "partner", "fixture", partners
        )
        reproduced["partner/denominators"] = write_and_check(
            out, "partner", "denominators", statuses
        )
    seeds, summary = scale.aggregate(scales)
    omitted = scale.match_influence(scales, summary)
    for name, table in (
        ("seed", seeds),
        ("summary", summary),
        ("leave_one_match_out", omitted),
    ):
        reproduced[f"scale/{name}"] = write_and_check(out, "scale", name, table)
    seeds, summary = partner.aggregate(partners)
    for name, table in (("seed", seeds), ("summary", summary)):
        reproduced[f"partner/{name}"] = write_and_check(out, "partner", name, table)
    with (REFERENCE / "partner/denominators.csv").open(
        encoding="utf-8-sig", newline=""
    ) as handle:
        statuses = list(csv.DictReader(handle))
    for seed in (s for s in seeds if s["scope"] == "primary_per_seed"):
        group = [
            r
            for r in statuses
            if r["reader"] == seed["reader"] and int(r["seed"]) == seed["seed"]
        ]
        assert sum(int(r["windows"]) for r in group) == seed["planned"]
        assert (
            sum(int(r["windows"]) for r in group if r["status"] == "PAIRED_COMPLETE")
            == seed["pairs"]
        )
    return {
        "mode": args.mode,
        "status": "PASS",
        "new_training_updates": 0,
        "model_forwards": 0,
        "aggregate_reference_files_checked": len(checks),
        "local_input_hashes": LOCAL_INPUTS if local else {},
        "diagnostics": diagnostics,
        "regenerated_csv": reproduced,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_subparsers(dest="mode", required=True)
    public = modes.add_parser(
        "aggregates", help="Recompute from the supplied fixture tables"
    )
    local = modes.add_parser(
        "local-values", help="Recompute from the exact authorized upstream values"
    )
    for option in LOCAL_INPUTS:
        local.add_argument("--" + option.replace("_", "-"), required=True, type=Path)
    for mode in (public, local):
        mode.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if not __debug__:
        parser.error(
            "Use Python without -O; the original scientific checks use assertions"
        )
    if args.out.exists():
        parser.error("Output directory already exists")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out.parent) as tmp:
        out = Path(tmp) / "result"
        out.mkdir()
        receipt = run(args, out)
        (out / "receipt.json").write_text(
            json.dumps(receipt, indent=2) + "\n", encoding="utf-8"
        )
        out.rename(args.out)
    print(
        "PASS",
        args.mode,
        len(receipt["regenerated_csv"]),
        "aggregate tables regenerated and matched",
    )


if __name__ == "__main__":
    main()
