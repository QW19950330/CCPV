# Two-player attribution in the frozen football models

This package reproduces three descriptive checks on 12 previously analysed development matches. The first changes the probability measurement scale while holding both players, their actions and the model's four coalition scores fixed. The second omits each match in turn. The third keeps the focal player A and its command fixed while replacing teammate B with the nearest eligible off-ball teammate C at the decision frame.

## Reproduce the aggregate tables

Run the following from this directory with Python 3.11 and NumPy 1.26.4. Use a new output directory for each run.

```sh
python -B replay.py aggregates --out reproduced_aggregates
```

The command uses only the enclosed fixture-level inputs. It rebuilds the 40 scale seed rows, eight scale summaries, 96 leave-one-match-out rows, 20 partner seed rows and 60 partner summary rows. It compares all five output CSVs byte for byte to the reference and checks the separate partner count ledger against the primary coverage in each match-aggregated seed. The fixture summaries and the number of rejected paths are inputs at this level. The case-level scores and player identities are unnecessary here.

## Reproduce from authorized upstream values

The local-value route needs the original archived objects below. The three case-level CSVs are external inputs to this candidate. Their SHA-256 values are pinned in the command. The public aggregate route above runs without them.

| Argument | Required content |
|---|---|
| `--coalitions` | `paired_reference_scene.csv`: archived natural-continuation and maintained-initial-velocity coalition scores, both trained readouts, five frozen seeds, case IDs and common-support flags. |
| `--roles` | `pair_role_groups.csv`: independent lookup of the pair's observed home-possession status at the decision frame, with the frozen frame and player identities. |
| `--partner-cases` | `scene.csv` from the uniform-layout six-coalition run, including incomplete cases, support/status fields and the scalar scores and allocations. |

```sh
python -B replay.py local-values --coalitions INPUT/paired_reference_scene.csv --roles INPUT/pair_role_groups.csv --partner-cases INPUT/uniform/scene.csv --out reproduced_from_values
```

This route regenerates all eight aggregate CSVs. It joins the roles by row, match, original source index and both player IDs. Of 680 common windows, 70 are confirmed home-team nonpossessor pairs, 324 are known to fall outside that definition and 286 lack sufficient evidence. These categories describe recorded possession at the decision time. Tactical intent and the consequences of an unexecuted command remain unobserved.

## Regenerate the replacement choice and the six model scores

The two commands below operate on authorized inputs and write player-level records to the chosen local destination. Their public CPU dependencies are NumPy 1.26.4 and PyTorch 2.7.0. For the second command, obtain the CCPV source checkout and extract the published clean numeric inference weights. The verified source checkout was `e63b1a380e401e82760c9c0e5ab0d4ebef339f23`. The package pins the 5 trajectory checkpoints and the 2 readers × 5 seeds × 6 folds through the original-to-clean weight identities. The original fixed readout implementation is included as `shared_value_math.py`. [Source checkout](https://github.com/QW19950330/CCPV/tree/e63b1a380e401e82760c9c0e5ab0d4ebef339f23) · [Clean weight archive](https://doi.org/10.5281/zenodo.24370617)

```sh
python -B select_partner.py --prefix INPUT/train_prefixes.npz --roles INPUT/pair_role_groups.csv --role-details INPUT/window_roles.csv --raw-root SKILLCORNER_CHECKOUT --out selection
python -B run_partner_uniform.py --prefix INPUT/train_prefixes.npz --context INPUT/prefix.npz --commands INPUT/fixed_commands.npz --selection selection/selection.csv --coalitions INPUT/paired_reference_scene.csv --public-repo CCPV_CHECKOUT --weights-root CLEAN_WEIGHTS --reference-states SEED0/states.npz SEED1/states.npz SEED2/states.npz SEED3/states.npz SEED4/states.npz --out uniform
```

The first command reads the exact training-prefix NPZ, the two role tables, and 12 pairs of original roster/tracking files under the pinned provider checkout. The role details must include candidate slots, the current recorded possessor and team consistency. It matches roster, period, frame, detection status, initial velocity and observed possession, excludes A, B and the carrier, and resolves distance ties by source player ID. Of the 70 windows considered, 69 had a replacement. Selection and all candidate distance ranks are checked against the original files. [Pinned SkillCorner sources](https://github.com/SkillCorner/opendata/tree/4340d274572876239c154c90bc507a9b3250a656)

The second command requires the archived development-cohort context NPZ (`X0`, `old_CV8`, `prefix_supported`), original fixed commands, local four-coalition reference table, and one original path/status/support archive per seed in seed order 0–4. These intermediary objects and the two role tables are not in this candidate. Filenames alone are insufficient. The complete input hashes, public provider filenames, motion limits and reader/seed/fold identities are in [the input specification](inference_inputs.json). Access to the public weights alone does not supply the original intermediates. The two commands expose the selection and inference calculations and allow a holder of the exact inputs to replay them.

The run uses the same ordered batch of 760 eligible rows for both games, all 23 model entities, the frozen 20-step persistent commands, deterministic CPU execution and the mathematical attention backend. It recomputes the four original paths, substitutes C only on the 69 eligible rows and checks the shared unedited and A-only paths. Scores are means of the six frozen fold probabilities. Each original world-model checkpoint corresponds to the four-epoch pilot. No parameter update is performed. The resulting `uniform/scene.csv` feeds `replay.py local-values`. The four-coalition scores for the 680-window scale analysis are upstream inputs. The new six-path inference covers the partner diagnostic. Intermediate model states and row-level outputs are for local verification.

## Verification

The authors ran all three routes. A separate directory containing only 12 public files reproduced the five aggregate tables. The raw-source selection reproduced both selection and distance-ranking CSVs byte for byte. The five-seed model run reproduced the 700-row score CSV and all five trajectory archives byte for byte. The largest difference from the earlier four-coalition reference was 6.94 × 10⁻¹⁷, and the two shared anchors agreed exactly for both readers. Using the newly generated scores reproduced all eight aggregate tables. [Verification receipt](verified_replay.json)

## Interpretation

The probability interaction is `qAB − qA − qB + q0`. The scale calculation compares its sign to the interaction formed after applying logit to each score. The reversal rate includes windows in which both interactions exceed 10⁻¹² in absolute value. Terms attributed to transformation curvature and the residual are recorded separately. In the primary reader, the mean sign reversal rate over the 680-window cohort was 9.14% under natural continuation and 2.23% under maintained initial velocity, with matches weighted equally within each seed. Leaving one match out gives ranges of 8.69–9.46% and 1.88–2.37%, respectively.

For partner P, the focal allocation is `[(qA − q0) + (qAP − qP)] / 2`. The change when replacing B with C is half the corresponding change in interaction because A and the reference remain fixed. In the primary reader, the mean absolute change was 7.733 × 10⁻⁷ on the probability scale; in the alternate reader it was 1.933 × 10⁻⁶. The completed sample sizes were 69, 68, 69, 69 and 69 out of 70 windows across seeds. These are overlapping measurements of model allocations on fixed development games.
