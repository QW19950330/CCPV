"""Six real autoregressive paths; rerun the archived four-path game before the new two paths."""
import argparse, gc, sys
import importlib.util
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import torch
from torch.nn.attention import sdpa_kernel, SDPBackend
from select_partner import HERE, j, table, sha, put, loadpin, write_csv
import shared_value_math as V


def finite_q(z):
    return float(z) if np.isfinite(z) else None


def compute_pair(api, op, model, a, idx, targets, which, context, limits, cps):
    registries = op.make_registries(
        a["entity_ids"][idx], a["identity_status"][idx], a["teams"]
    )
    history = torch.tensor(a["history_states"][idx])
    valid = torch.tensor(a["history_valid"][idx])
    teams = torch.tensor(a["teams"], dtype=torch.long)
    commands = op.make_commands(history, registries, targets, delta0=False)
    units = op.MetricUnits("m", "m/s", "s", "m/s^2", "rad/s")
    outputs = {}
    for name, coalition in which:
        ret = op.rollout(
            api,
            model,
            history,
            valid,
            teams,
            registries,
            targets,
            commands if coalition else None,
            coalition,
            "persistent" if coalition else "bypass",
            limits,
            units=units,
            dt=float(api.DT),
            horizon=20,
        )
        states = ret["states"].numpy()
        support = ret["support"].numpy()
        steps = ret["completed_steps"].numpy()
        raw, ok = V.path_features(
            history.numpy(),
            valid.numpy(),
            a["entity_ids"][idx],
            states,
            support,
            steps,
            context["X0"][idx],
            context["old_CV8"][idx],
        )
        ok = ok & context["prefix_supported"][idx]
        qs = {}
        for reader, heads in cps.items():
            qs[reader] = np.full(len(idx), np.nan)
            if ok.any():
                lp, ln = V.probability_mean(
                    [V.predict_direct(cp, raw[ok]) for cp in heads]
                )
                assert np.max(np.abs(np.exp(lp) + np.exp(ln) - 1)) < 1e-12
                qs[reader][ok] = np.exp(lp)
        outputs[name] = dict(
            states=states,
            support=support,
            steps=steps,
            status=np.asarray(ret["scene_status"]),
            reasons=np.array([" | ".join(items) for items in ret["scene_reasons"]]),
            raw=raw,
            q=qs,
            forward=ret["learned_batch_forward_calls"],
            requests=ret["actual_operator_calls"],
        )
        del ret
    return outputs, commands.numpy()


def run(args):
    pins = j(HERE / "inference_inputs.json")
    for name in ("prefix", "context", "commands", "selection", "coalitions"):
        assert sha(getattr(args, name)) == pins[name], name
    for name, expected in zip(args.reference_states, pins["old_states"], strict=True):
        assert sha(name) == expected, name
    assert sha(Path(V.__file__)) == pins["score_code"]
    bridge_path = (
        args.public_repo / "bundles/diagnostic_portable/run_clean_diagnostic.py"
    )
    assert sha(bridge_path) == pins["public_bridge"]
    spec = importlib.util.spec_from_file_location(
        "public_clean_diagnostic", bridge_path
    )
    bridge = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bridge)
    binding, _, runtime_torch, api, op, clean = bridge.verified_runtime(
        pins["public_binding"]
    )
    assert runtime_torch is torch
    api.configure("cpu")
    assert torch.get_num_threads() == 1 and torch.are_deterministic_algorithms_enabled()
    manifest = args.weights_root / "inference_manifest.json"
    assert sha(manifest) == pins["weight_manifest"]
    public_heads = {r["original_sha256"]: r for r in j(manifest)["files"]}

    def load_head(reader, seed, fold):
        entry = public_heads[pins["heads"][reader][seed][fold]]
        arrays = clean.load_export(entry, args.weights_root)
        return {k: arrays[k] for k in V.CP_KEYS}

    original_csv = args.coalitions
    a = loadpin(
        {"path": args.prefix, "sha256": pins["prefix"]},
        (
            "source_indices",
            "match_ids",
            "operator_candidate_ids",
            "operator_case_status",
            "history_states",
            "history_valid",
            "entity_ids",
            "identity_status",
            "teams",
        ),
    )
    context = loadpin(
        {"path": args.context, "sha256": pins["context"]},
        ("source_indices", "match_ids", "X0", "old_CV8", "prefix_supported"),
    )
    assert np.array_equal(
        a["source_indices"], context["source_indices"]
    ) and np.array_equal(a["match_ids"], context["match_ids"])
    original_commands = loadpin(
        {"path": args.commands, "sha256": pins["commands"]},
        ("source_indices", "absolute_velocity", "target_source_ids"),
    )
    assert np.array_equal(
        a["operator_candidate_ids"], original_commands["target_source_ids"]
    )
    selection = table(args.selection)
    base_idx = np.array([int(r["row"]) for r in selection])
    chosen = [r for r in selection if r["status"] == "SELECTED"]
    alt_idx = np.array([int(r["row"]) for r in chosen])
    alt_targets = [[r["A_id"], r["C_id"]] for r in chosen]
    old_q = {
        (int(r["scene_index"]), int(r["seed"]), r["value_family"]): r
        for r in table(original_csv)
        if r["world_arm"] == "D_coupled_ar"
        and r["common_reference_intersection"] == "True"
        and int(r["scene_index"]) in set(base_idx)
    }
    req = pins["limits"]
    limits = op.MotionLimits(req["speed"], req["acceleration"], req["turn"])
    outrows = []
    proofs = []
    attempts = []
    files = []
    dest = args.out
    dest.mkdir(parents=True, exist_ok=False)
    model_records = binding["models"]
    assert [r["original_checkpoint_sha256"] for r in model_records] == pins[
        "original_models"
    ]
    put(
        dest / "launch.json",
        dict(
            utc=datetime.now(timezone.utc).isoformat(),
            torch=torch.__version__,
            code=sha(Path(__file__)),
            selector=pins["selection"],
            clean_binding=pins["public_binding"],
        ),
    )
    baseline_paths = [("0", ()), ("A", (0,)), ("B", (1,)), ("AB", (0, 1))]
    alternative_paths = [("C", (1,)), ("AC", (0, 1))]
    pathkeys = {
        "0": "baseline",
        "A": "persistent_A",
        "B": "persistent_B",
        "AB": "persistent_AB",
    }
    qkeys = {"0": "empty", "A": "A", "B": "B", "AB": "AB"}
    for seed in range(5):
        model = bridge.load_model(
            model_records[seed], args.weights_root, torch, api, clean
        )
        for v in model.parameters():
            v.requires_grad_(False)
        before = api.state_hash(model.state_dict())
        cps = {
            reader: [load_head(reader, seed, fold) for fold in range(6)]
            for reader in V.VALUE_FAMILIES
        }
        old = loadpin(
            {"path": args.reference_states[seed], "sha256": pins["old_states"][seed]},
            ("paths", "completed_steps", "scene_status", "support"),
        )
        oldmap = {str(n): i for i, n in enumerate(old["paths"])}
        with torch.inference_mode(), sdpa_kernel([SDPBackend.MATH]):
            for layout, ix in [
                (
                    "original760-both-games",
                    np.flatnonzero(
                        a["operator_case_status"]
                        == "SUPPORTED_TWO_SOURCE_HOME_T0_VALID"
                    ),
                )
            ]:
                base, cmd = compute_pair(
                    api,
                    op,
                    model,
                    a,
                    ix,
                    a["operator_candidate_ids"][ix].tolist(),
                    baseline_paths,
                    context,
                    limits,
                    cps,
                )
                assert np.array_equal(cmd, original_commands["absolute_velocity"][ix])
                pos = np.searchsorted(ix, base_idx)
                assert np.array_equal(ix[pos], base_idx)
                replay = []
                for k, v in base.items():
                    opix = oldmap[pathkeys[k]]
                    ok = all(
                        np.array_equal(v[name][pos], old[oldname][opix, base_idx])
                        for name, oldname in [
                            ("steps", "completed_steps"),
                            ("status", "scene_status"),
                            ("support", "support"),
                        ]
                    )
                    worst = max(
                        abs(
                            v["q"][reader][p0]
                            - float(
                                old_q[(int(row), seed, reader)]["old_q_" + qkeys[k]]
                            )
                        )
                        for reader in cps
                        for p0, row in zip(pos, base_idx)
                    )
                    replay.append(
                        dict(
                            path=k,
                            old_status_support_exact=ok,
                            max_abs_q=float(worst),
                            pass_replay=bool(
                                ok and np.isfinite(worst) and worst <= 1e-7
                            ),
                        )
                    )
                attempts.append(dict(seed=seed, layout=layout, results=replay))
                if all(t["pass_replay"] for t in replay):
                    break
                print("REPLAY_LAYOUT_FAILED", seed, layout, replay, flush=True)
            else:
                put(dest / "failed_original_replay.json", attempts)
                raise ValueError("Original probability replay failed")
            # Preserve every row and its position in the archived full batch. Substitute C on only the prespecified 69 rows.
            fulltargets = a["operator_candidate_ids"][ix].tolist()
            ri = np.searchsorted(ix, alt_idx)
            assert np.array_equal(ix[ri], alt_idx)
            for at, actors in zip(ri, alt_targets):
                assert fulltargets[at][0] == actors[0]
                fulltargets[at] = actors
            alt, cmd760 = compute_pair(
                api,
                op,
                model,
                a,
                ix,
                fulltargets,
                alternative_paths + [("anchor0", ()), ("anchorA", (0,))],
                context,
                limits,
                cps,
            )
            acmd = cmd760[ri]
            for v in alt.values():
                v["q"] = {h: z[ri] for h, z in v["q"].items()}
                for item in ("states", "support", "steps", "status", "raw", "reasons"):
                    v[item] = v[item][ri]
            assert np.array_equal(
                acmd[:, 0], original_commands["absolute_velocity"][alt_idx, 0]
            )
            layout_checks = []
            for name, key in [("anchor0", "0"), ("anchorA", "A")]:
                z = alt.pop(name)
                v = base[key]
                pp = np.searchsorted(ix, alt_idx)
                exact = all(
                    np.array_equal(z[n], v[n][pp])
                    for n in ("status", "support", "steps")
                )
                diff = {
                    h: float(np.max(np.abs(z["q"][h] - v["q"][h][pp]))) for h in cps
                }
                layout_checks.append(
                    dict(
                        path=key,
                        status_support_steps_exact=exact,
                        max_abs_q_by_reader=diff,
                    )
                )
                assert exact and all(
                    np.isfinite(val) and val <= 1e-12 for val in diff.values()
                ), layout_checks
        assert api.state_hash(model.state_dict()) == before
        full = {}
        for k, v in {**base, **alt}.items():
            subset = base_idx if k in base else alt_idx
            loc = pos if k in base else np.arange(len(alt_idx))
            for name in ("states", "support", "steps", "status", "raw", "reasons"):
                full[k + "_" + name] = v[name][loc]
            full[k + "_rows"] = subset
        full["AC_commands"] = acmd
        target = dest / f"seed{seed}_trajectories.npz"
        with target.open("xb") as f:
            np.savez_compressed(f, **full)
        files.append({"path": target.name, "sha256": sha(target)})
        for i, r in enumerate(selection):
            row = int(r["row"])
            altloc = np.flatnonzero(alt_idx == row)
            for reader in cps:
                record = dict(
                    match_id=r["match_id"],
                    row=row,
                    source_index=int(r["source_index"]),
                    seed=seed,
                    reader=reader,
                    A_id=r["A_id"],
                    B_id=r["B_id"],
                    C_id=r["C_id"],
                    status=r["status"],
                )
                record.update(
                    {"q" + k: finite_q(v["q"][reader][pos[i]]) for k, v in base.items()}
                )
                for k, v in alt.items():
                    record["q" + k] = (
                        finite_q(v["q"][reader][altloc[0]]) if altloc.size else None
                    )
                    record["status_" + k] = (
                        str(v["status"][altloc[0]]) if altloc.size else "NO_C"
                    )
                    record["reason_" + k] = (
                        str(v["reasons"][altloc[0]])
                        if altloc.size
                        else "NO_OTHER_ELIGIBLE_TEAMMATE"
                    )
                    record["steps_" + k] = (
                        int(v["steps"][altloc[0]]) if altloc.size else None
                    )
                pAB = 0.5 * (
                    (record["qA"] - record["q0"]) + (record["qAB"] - record["qB"])
                )
                pAC = (
                    None
                    if record["qC"] is None or record["qAC"] is None
                    else 0.5
                    * ((record["qA"] - record["q0"]) + (record["qAC"] - record["qC"]))
                )
                record.update(
                    phi_AB=pAB, phi_AC=pAC, delta=None if pAC is None else pAC - pAB
                )
                if r["status"] == "SELECTED":
                    record["status"] = (
                        "PAIRED_COMPLETE"
                        if pAC is not None
                        else "INCOMPLETE_ALTERNATIVE"
                    )
                outrows.append(record)
        proofs.append(
            dict(
                seed=seed,
                layout=layout,
                checkpoint_sha256=pins["original_models"][seed],
                unchanged_world_state=before,
                replay=replay,
                alternative_layout_anchor_replay=layout_checks,
                steps={k: v["forward"] for k, v in {**base, **alt}.items()},
                requests={k: v["requests"] for k, v in {**base, **alt}.items()},
            )
        )
        put(dest / f"seed{seed}_receipt.json", proofs[-1])
        print(
            "SEED_DONE",
            seed,
            "layout",
            layout,
            "max_abs_q",
            max(x["max_abs_q"] for x in replay),
            "new_paths_completed",
            [(k, int(np.sum(v["steps"] == 20))) for k, v in alt.items()],
            flush=True,
        )
        del old, full, base, alt, model
        gc.collect()
    out = dest
    write_csv(out / "scene.csv", outrows)
    put(
        out / "run_receipt.json",
        dict(
            utc=datetime.now(timezone.utc).isoformat(),
            status="PASSED_FIVE_SEED_ACTUAL_ROLLOUTS_AND_NUMERIC_REPLAY",
            proofs=proofs,
            attempts=attempts,
            trajectories=files,
            scene_csv=sha(out / "scene.csv"),
            additional_training=0,
            no_outcomes=True,
            input_spec=sha(HERE / "inference_inputs.json"),
        ),
    )
    assert (
        sha(out / "scene.csv")
        == "c41e014e8946d22c3ace1b9616f05552b216bb45371a13a8ffcc5ee15e35de8a"
    ), "Six coalition score table differs from the frozen uniform-layout run"


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "prefix",
        "context",
        "commands",
        "selection",
        "coalitions",
        "public-repo",
        "weights-root",
        "out",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument(
        "--reference-states", type=Path, nargs=5, required=True, metavar="SEED_STATE"
    )
    if not __debug__:
        parser.error("Assertions must be enabled")
    run(parser.parse_args())
