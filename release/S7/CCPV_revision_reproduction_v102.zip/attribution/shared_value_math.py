"""Pure NumPy saved-path dictionary and frozen Direct readout; no file access.

Coordinate inputs are the already decoded old world-model coordinates, whose
SkillCorner source was standardized to 105 x 68. No new scale or direction fit.
The query is fixed roster-home (A=0), never inferred possession/attack role.
"""
from __future__ import annotations
import numpy as np

WORLD_ARMS = ('A_raw4d', 'C_coupled_tf', 'D_coupled_ar', 'CV')
VALUE_FAMILIES = ('CV_Direct_WithEarlyBCE', 'D_Direct_WithEarlyBCE')
PATHS = ('baseline', 'none_every_step', 'first_A', 'first_B', 'first_AB',
         'persistent_A', 'persistent_B', 'persistent_AB', 'persistent_delta0_AB')
GAMES = {'first': ('baseline', 'first_A', 'first_B', 'first_AB'),
         'persistent': ('baseline', 'persistent_A', 'persistent_B', 'persistent_AB')}
TEAMS = np.array([0] * 11 + [1] * 11 + [2], np.int64)
CP_KEYS = ('hidden_weight', 'hidden_bias', 'output_weight', 'output_bias',
           'scaler_mean', 'scaler_scale', 'scaler_completely_absent_training_feature')


def snapshot(xy, present, ids):
    players = {}
    for team, slots in ((0, range(11)), (1, range(11, 22))):
        players[team] = {str(ids[j]): np.asarray(xy[j], np.float64)
                         for j in slots if present[j] and ids[j] and np.isfinite(xy[j]).all()}
    ball = np.asarray(xy[22], np.float64) if present[22] and np.isfinite(xy[22]).all() else None
    return dict(ball=ball, players=players)


def pair_features(previous, current):
    x = np.full(10, np.nan)
    common = {t: sorted(set(previous['players'].get(t, {})) & set(current['players'].get(t, {})))
              for t in (0, 1)}
    b0, b1 = previous['ball'], current['ball']
    if b1 is not None:
        x[:2] = np.abs(b1)
    for team, start in ((0, 2), (1, 4)):
        if b1 is not None and common[team]:
            xy = np.array([current['players'][team][i] for i in common[team]])
            d = np.linalg.norm(xy - b1, axis=-1)
            x[start:start + 2] = [d.min(), d.mean()]
        if common[team]:
            v = np.array([(current['players'][team][i] - previous['players'][team][i]) / .2
                          for i in common[team]])
            x[8 if team == 0 else 9] = np.linalg.norm(v, axis=-1).mean()
    if b0 is not None and b1 is not None:
        x[6:8] = np.sign(b1) * (b1 - b0) / .2
    return x


def cv_snapshots(previous, current):
    if previous['ball'] is None or current['ball'] is None:
        return None
    common = {t: sorted(set(previous['players'][t]) & set(current['players'][t])) for t in (0, 1)}
    bv = (current['ball'] - previous['ball']) / .2
    v = {t: {i: (current['players'][t][i] - previous['players'][t][i]) / .2
             for i in common[t]} for t in (0, 1)}
    # Literal original 25-Hz feature offsets, not old world-CV velocity heads.
    return [dict(ball=current['ball'] + float(d) / 25 * bv,
                 players={t: {i: current['players'][t][i] + float(d) / 25 * v[t][i]
                              for i in common[t]} for t in (0, 1)})
            for d in range(-5, 51, 5)]


def decoder_summary(snapshots):
    z = np.full(8, np.nan)
    if snapshots is None:
        return z
    b = np.array([s['ball'] if s['ball'] is not None else [np.nan, np.nan] for s in snapshots])
    v = np.diff(b, axis=0) / .2
    if np.isfinite(v).all():
        speed = np.linalg.norm(v, axis=-1)
        z[:2] = [speed.mean(), speed.max()]
        z[2] = np.linalg.norm(np.diff(v, axis=0) / .2, axis=-1).max()
    if np.isfinite(b[[1, -1]]).all():
        z[3] = np.linalg.norm(b[-1] - b[1])
    for team, start in ((0, 4), (1, 6)):
        d = [min(np.linalg.norm(p - s['ball']) for p in s['players'].get(team, {}).values())
             if s['players'].get(team) and s['ball'] is not None else np.nan for s in snapshots[1:]]
        if np.isfinite(d).all():
            z[start:start + 2] = [np.min(d), np.mean(d)]
    return z


def validate_prefix(history, valid, position_valid, ids, teams):
    if (history.shape[1:] != (10, 23, 4) or history.dtype != np.float32
            or valid.shape != history.shape[:-1] or valid.dtype != bool
            or position_valid.shape != valid.shape or position_valid.dtype != bool
            or ids.shape != (len(history), 23) or not np.array_equal(teams, TEAMS)):
        raise ValueError('Saved prefix contract mismatch')
    if np.any(valid & ~position_valid) or not np.isfinite(history[valid]).all():
        raise ValueError('Invalid saved prefix mask or values')
    for row in range(len(history)):
        nonempty = ids[row][ids[row] != ''].astype(str).tolist()
        if len(nonempty) != len(set(nonempty)) or str(ids[row, 22]).casefold() != 'ball':
            raise ValueError('Source ID uniqueness/ball identity mismatch')
        if np.any(valid[row].any(0) & (ids[row] == '')):
            raise ValueError('Usable entity without stable source identity')


def prefix_features(history, valid, ids):
    """Only stored prefix xy with full-state valid survives old zero-masking.

    position_valid is deliberately NOT used: old states[~valid] were zeroed.
    Missing X0 features are retained for the frozen head's missing indicators.
    """
    n = len(history)
    x0, cv8 = np.full((n, 10), np.nan), np.full((n, 8), np.nan)
    seen = valid.any(1)
    supported = seen[:, 22] & seen[:, :11].any(1) & seen[:, 11:22].any(1)
    for r in range(n):
        prev, current = [snapshot(history[r, t, :, :2], valid[r, t], ids[r]) for t in (7, 9)]
        x0[r] = pair_features(prev, current)
        cv8[r] = decoder_summary(cv_snapshots(prev, current))
    return x0, cv8, supported


def path_features(history, valid, ids, generated, support, completed, x0, cv8):
    n = len(history)
    if (generated.shape != (n, 20, 23, 4) or support.shape != (n, 20, 23)
            or support.dtype != bool or completed.shape != (n,)):
        raise ValueError('Saved full joint path shape mismatch')
    if np.any((completed < 0) | (completed > 20)):
        raise ValueError('Invalid completed path length')
    seen = valid.any(1)
    for r in range(n):
        k = int(completed[r])
        if support[r, k:].any() or np.any(support[r] & ~seen[r][None]):
            raise ValueError('Saved support exceeds generated prefix/source presence')
    if not np.isfinite(generated[support]).all():
        raise ValueError('Nonfinite supported generated coordinate')
    raw = np.full((n, 36), np.nan)
    raw[:, :10], raw[:, 10:18] = x0, cv8
    complete = completed == 20
    for r in np.flatnonzero(complete):
        snaps = [snapshot(history[r, t, :, :2], valid[r, t], ids[r]) for t in (7, 9)]
        snaps += [snapshot(generated[r, t, :, :2], support[r, t], ids[r]) for t in range(1, 20, 2)]
        raw[r, 18:26] = decoder_summary(snaps)
        raw[r, 26:] = pair_features(snaps[-2], snaps[-1])
    return raw, complete


def predict_direct(cp, raw):
    """Prediction-only API: no labels, fit, Torch model or RNG."""
    x = np.asarray(raw, np.float64)
    if x.ndim != 2 or x.shape[1] != 36:
        raise ValueError('Need Raw36')
    shapes = dict(hidden_weight=(8, 72), hidden_bias=(8,), output_weight=(2, 8), output_bias=(2,),
                  scaler_mean=(36,), scaler_scale=(36,), scaler_completely_absent_training_feature=(36,))
    for key, shape in shapes.items():
        if np.asarray(cp[key]).shape != shape:
            raise ValueError('Frozen CP shape ' + key)
    available = np.isfinite(x)
    scale = cp['scaler_scale']
    if not np.isfinite(scale).all() or np.any(scale <= 0):
        raise ValueError('Invalid frozen scaler')
    z = np.where(available, (x - cp['scaler_mean']) / scale, 0.)
    z[:, np.asarray(cp['scaler_completely_absent_training_feature'], bool)] = 0.
    encoded = np.concatenate((z, (~available).astype(np.float64)), 1)
    if not np.isfinite(encoded).all():
        raise FloatingPointError('Canonical fixed encoded72 must be finite')
    # Evaluate the ENTIRE frozen function once per distinct numerical input.
    # This is general, with no baseline/NONE/path/arm-specific branch.
    unique, inverse = np.unique(encoded, axis=0, return_inverse=True)
    logits = np.tanh(unique @ cp['hidden_weight'].T + cp['hidden_bias']) @ cp['output_weight'].T + cp['output_bias']
    if not np.isfinite(logits).all():
        raise FloatingPointError('Frozen readout nonfinite')
    logp = -np.logaddexp(0., -logits[:, 0])
    log1mp = -np.logaddexp(0., logits[:, 0])
    return logp[inverse], log1mp[inverse]


def probability_mean(logpairs):
    if len(logpairs) != 6:
        raise ValueError('Frozen six-fold probability ensemble required')
    p, n = [np.stack([x[j] for x in logpairs]) for j in (0, 1)]
    return np.logaddexp.reduce(p, axis=0) - np.log(6.), np.logaddexp.reduce(n, axis=0) - np.log(6.)


def exact_game(v):
    """Last axis empty,A,B,AB; K2 standard Shapley and half interaction."""
    v = np.asarray(v, np.float64)
    if v.shape[-1] != 4:
        raise ValueError('Need actual four coalition readouts')
    z, a, b, ab = np.moveaxis(v, -1, 0)
    phi_a = .5 * ((a - z) + (ab - b))
    phi_b = .5 * ((b - z) + (ab - a))
    interaction = ab - a - b + z
    return dict(delta_A=a-z, delta_B=b-z, delta_AB=ab-z, phi_A=phi_a, phi_B=phi_b,
                interaction_difference=interaction, shapley_pair_half=.5*interaction,
                efficiency_error=phi_a+phi_b-(ab-z))


def average_rank(values):
    """Average ties; deterministic no effect-based winner selection."""
    x = np.asarray(values, np.float64)
    order = np.argsort(x, kind='stable')
    result = np.empty(len(x), np.float64)
    i = 0
    while i < len(x):
        j = i + 1
        while j < len(x) and x[order[j]] == x[order[i]]:
            j += 1
        result[order[i:j]] = (i + j - 1) / 2 + 1
        i = j
    return result


def rank_correlation(x, y):
    good = np.isfinite(x) & np.isfinite(y)
    if good.sum() < 2:
        return None, int(good.sum())
    a, b = average_rank(np.asarray(x)[good]), average_rank(np.asarray(y)[good])
    if np.ptp(a) == 0 or np.ptp(b) == 0:
        return None, int(good.sum())
    return float(np.corrcoef(a, b)[0, 1]), int(good.sum())


def actor_order(phi_a, phi_b):
    """Within-scene ordering of the TWO fixed actors; exact float-zero ties.

    No tolerance/threshold is selected from effects. This is distinct from
    ranking scenes by delta_AB. Undefined values keep a NaN order.
    """
    gap = np.asarray(phi_a, np.float64) - np.asarray(phi_b, np.float64)
    return gap, np.sign(gap)


def actor_agreement(left, right, mask):
    left, right, mask = np.asarray(left), np.asarray(right), np.asarray(mask, bool)
    if left.shape != right.shape or left.shape != mask.shape:
        raise ValueError('Actor ordering alignment mismatch')
    if not np.isin(left[mask], [-1., 0., 1.]).all() or not np.isin(right[mask], [-1., 0., 1.]).all():
        raise ValueError('Undefined actor ordering on requested paired support')
    a,b=left[mask],right[mask]
    lt,rt=a==0,b==0
    non=~lt&~rt
    n=int(len(a)); nn=int(non.sum())
    same=int(np.sum((a==b)&non))
    allsame=int(np.sum(a==b))
    return dict(paired_scenes=n, both_nontie_scenes=nn, both_tie_scenes=int(np.sum(lt&rt)),
                left_only_tie_scenes=int(np.sum(lt&~rt)),right_only_tie_scenes=int(np.sum(~lt&rt)),
                at_least_one_tie_scenes=int(np.sum(lt|rt)), strict_order_agree_scenes=same,
                strict_order_reverse_scenes=int(np.sum((a!=b)&non)),
                order_agreement_including_both_ties_scenes=allsame,
                strict_order_agreement_fraction=same/nn if nn else None,
                agreement_including_both_ties_fraction=allsame/n if n else None)
