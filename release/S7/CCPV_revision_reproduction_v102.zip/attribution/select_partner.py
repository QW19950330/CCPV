"""Select the nearest eligible teammate using only the t0 frame and previously frozen identities."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
import csv, hashlib, json, math, re
import numpy as np

HERE = Path(__file__).resolve().parent


def j(p):
    return json.loads(Path(p).read_text(encoding="utf-8-sig"))


def table(p):
    with Path(p).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def sha(p):
    with Path(p).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def put(p, data):
    with p.open("x", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)


def write_csv(p, rows):
    with p.open("x", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def loadpin(rec, keys):
    assert sha(rec["path"]) == rec["sha256"], rec["path"]
    with np.load(rec["path"], allow_pickle=False) as z:
        return {k: z[k] for k in keys}


def select(args):
    pins = j(HERE / "inference_inputs.json")
    for name in ("prefix", "roles", "role_details"):
        assert sha(getattr(args, name)) == pins[name], name
    groups = [
        x
        for x in table(args.roles)
        if x["cohort"] == "train"
        and x["common680"] == "True"
        and x["role_group"] == "CONFIRMED_OWN_NONPOSSESSOR_PAIR"
    ]
    assert len(groups) == 70 and len({r["match_id"] for r in groups}) == 12
    roles = {r["row"]: r for r in table(args.role_details) if r["cohort"] == "train"}
    a = loadpin(
        {"path": args.prefix, "sha256": pins["prefix"]},
        (
            "source_indices",
            "match_ids",
            "entity_ids",
            "identity_status",
            "teams",
            "history_valid",
            "history_states",
            "operator_candidate_ids",
            "operator_candidate_slots",
            "source_frame_ids",
            "source_period",
        ),
    )
    raw = args.raw_root
    official = pins["published_raw_files"]
    rows = []
    source_shas = {}
    candidates = []
    for match in sorted({r["match_id"] for r in groups}):
        bucket = [r for r in groups if r["match_id"] == match]
        prefix = f"data/matches/{match}/{match}"
        mp = prefix + "_match.json"
        tp = prefix + "_tracking_extrapolated.jsonl"
        assert sha(raw / mp) == official[mp]
        meta = j(raw / mp)
        roster = {str(p["id"]): p for p in meta["players"]}
        home = str(meta["home_team"]["id"])
        frames = {int(r["t0_frame"]) for r in bucket}
        hits = defaultdict(list)
        h = hashlib.sha256()
        with (raw / tp).open("rb") as f:
            for line in f:
                h.update(line)
                m = re.search(rb'"frame"\s*:\s*(\d+)', line)
                if m and int(m[1]) in frames:
                    frame = json.loads(line)
                    hits[frame["period"], frame["frame"]].append(frame)
        assert h.hexdigest() == official[tp]
        source_shas[mp] = official[mp]
        source_shas[tp] = official[tp]
        for entry in bucket:
            ix = int(entry["row"])
            r = roles[entry["row"]]
            aid, bid = entry["A_id"], entry["B_id"]
            assert (
                int(a["source_indices"][ix]) == int(entry["source_index"])
                and str(a["match_ids"][ix]).split(":")[-1] == match
            )
            assert list(a["operator_candidate_ids"][ix]) == [aid, bid]
            per, fr = int(entry["period"]), int(entry["t0_frame"])
            assert (
                per == a["source_period"][ix]
                and fr == a["source_frame_ids"][ix, -1]
                and len(hits[per, fr]) == 1
            )
            frame = hits[per, fr][0]
            poss = str(frame["possession"]["player_id"])
            assert (
                poss == r["possessor_id"]
                and poss not in (aid, bid)
                and str(roster[poss]["team_id"]) == home
            )
            assert (
                frame["possession"]["group"] in ("home team", None)
                and r["provider_team_conflict"] == "False"
            )
            byid = defaultdict(list)
            for p in frame["player_data"]:
                byid[str(p["player_id"])].append(p)

            def detected(pid):
                ps = byid[pid]
                return (
                    len(ps) == 1
                    and ps[0]["is_detected"] is True
                    and all(
                        isinstance(ps[0].get(k), (int, float))
                        and math.isfinite(ps[0][k])
                        for k in ("x", "y")
                    )
                )

            base = dict(
                row=ix,
                match_id=match,
                source_index=int(entry["source_index"]),
                period=per,
                t0_frame=fr,
                A_id=aid,
                B_id=bid,
                A_slot=int(r["A_slot"]),
                B_slot=int(r["B_slot"]),
                possessor_id=poss,
                C_id="",
                C_slot="",
                distance_m="",
                candidate_count=0,
                C_position_group="",
                status="NO_DETECTED_UNIQUE_A",
            )
            if detected(aid):
                ax, ay = byid[aid][0]["x"], byid[aid][0]["y"]
                ranked = []
                for slot, eid in enumerate(a["entity_ids"][ix]):
                    pid = str(eid)
                    if (
                        a["teams"][slot] != 0
                        or not a["history_valid"][ix, -1, slot]
                        or a["identity_status"][ix, slot]
                        != "VERIFIED_SOURCE_PLAYER_TEAM"
                        or pid in (aid, bid, poss)
                        or not detected(pid)
                    ):
                        continue
                    assert (a["entity_ids"][ix] == pid).sum() == 1 and str(
                        roster[pid]["team_id"]
                    ) == home
                    px, py = byid[pid][0]["x"], byid[pid][0]["y"]
                    d2 = (px - ax) ** 2 + (py - ay) ** 2
                    ranked.append((d2, int(pid), slot, pid))
                ranked.sort()
                for rank, (d2, _, slot, pid) in enumerate(ranked, 1):
                    candidates.append(
                        dict(
                            row=ix,
                            match_id=match,
                            rank=rank,
                            slot=slot,
                            player_id=pid,
                            distance_m=math.sqrt(d2),
                        )
                    )
                base.update(
                    candidate_count=len(ranked), status="NO_OTHER_ELIGIBLE_TEAMMATE"
                )
                if ranked:
                    d2, _, slot, cid = ranked[0]
                    base.update(
                        C_id=cid,
                        C_slot=slot,
                        distance_m=math.sqrt(d2),
                        C_position_group=(roster[cid].get("player_role") or {}).get(
                            "position_group", ""
                        ),
                        status="SELECTED",
                    )
            rows.append(base)
    rows.sort(key=lambda r: r["row"])
    assert len({r["row"] for r in rows}) == 70
    args.out.mkdir(parents=True, exist_ok=False)
    write_csv(args.out / "selection.csv", rows)
    write_csv(args.out / "candidate_distances.csv", candidates)
    assert sha(args.out / "selection.csv") == pins["selection"]
    assert sha(args.out / "candidate_distances.csv") == pins["ranked_candidates"]
    receipt = {
        "selected_counts": dict(Counter(r["status"] for r in rows)),
        "fixtures": len({r["match_id"] for r in rows}),
        "source_files_verified": len(source_shas),
        "selection_sha256": pins["selection"],
        "ranked_candidates_sha256": pins["ranked_candidates"],
        "q_or_future_read_for_selection": False,
    }
    put(args.out / "selection_receipt.json", receipt)
    print(receipt)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("prefix", "roles", "role-details", "raw-root", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    if not __debug__:
        parser.error("Assertions must be enabled")
    select(parser.parse_args())
