"""Verify listed package members from an extracted revision supplement."""
import hashlib
import json
from pathlib import Path, PurePosixPath


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    for record in manifest["files"]:
        name = PurePosixPath(record["path"])
        if name.is_absolute() or ".." in name.parts:
            raise ValueError(f"Invalid manifest path {name}")
        path = root.joinpath(*name.parts)
        data = path.read_bytes()
        if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
            raise ValueError(f"File differs from inventory: {name}")
    print(f"Verified {len(manifest['files'])} file sizes and hashes.")


if __name__ == "__main__":
    main()
