"""Replay focal player forecast errors and coordinate-precision sensitivity."""
import argparse
import json
import platform
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from inputs import (BLOCK_INDEX, GROUPS_DIGEST, OPERATOR_DIGEST, PREFIX, PUBLIC_OPERATOR, TRUTH,
                    digest, load_clean_manifest, require, verified_arrays)
from precision import evaluate_precision
from roles import reconstruct
from scoring import evaluate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("prefix", "truth", "predictions", "skillcorner-root", "public-repo", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    require(__debug__, "Run without Python optimization")
    require(not args.out.exists(), "Use a fresh output directory")
    canonical = (Path(__file__).resolve().parent / "references.json").read_bytes()
    require(digest(canonical.replace(b"\r\n", b"\n")) ==
            "0728889ae80930c3f62be6be187c730f908ca2c899c8740910e335751291d57e", "Changed reference inventory")
    reference = json.loads(canonical)
    operator = args.public_repo / PUBLIC_OPERATOR
    require(digest((operator/"operator_adapter.py").read_bytes())==OPERATOR_DIGEST, "Changed intervention operator")
    sys.path.insert(0, str(operator.resolve()))
    from operator_adapter import make_commands

    prefix = verified_arrays(args.prefix, PREFIX)
    truth = verified_arrays(args.truth, TRUTH)
    manifest, manifest_hash = load_clean_manifest(args.predictions, args.truth)
    roles = reconstruct(prefix, args.skillcorner_root, reference)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out.parent) as temporary:
        work = Path(temporary) / "replay"
        work.mkdir()
        support, detail = evaluate(prefix, truth, manifest, args.predictions, roles, make_commands, work/"results")
        groups = support[["row","fixture","group"]].to_csv(index=False,lineterminator="\n").encode("utf-8")
        require(digest(groups)==GROUPS_DIGEST, "Early group identity mismatch")
        evaluate_precision(prefix, truth, support, detail, make_commands, work/"position_precision")
        table_checks = {}
        for name, expected in reference["tables"].items():
            raw = (work/name).read_bytes().replace(b"\r\n",b"\n")
            observed = {"lf_sha256": digest(raw), "data_rows": len(raw.splitlines())-1}
            require(observed == expected, f"Historical aggregate mismatch in {name}")
            table_checks[name] = observed
        result = dict(status="all_seven_aggregate_tables_match_historical_reference",
                      prefix_sha256=PREFIX,detected_truth_sha256=TRUTH,prediction_receipt_sha256=manifest_hash,
                      ordered_936_blocks_sha256=BLOCK_INDEX,operator_sha256=OPERATOR_DIGEST,
                      early_groups_lf_sha256=GROUPS_DIGEST,provider_revision=reference["provider_revision"],
                      provider_files_checked=len(reference["provider_files"]),role_mask_u8_sha256=digest(roles.astype("uint8").tobytes()),
                      planned_windows=len(support),confirmed_pair_windows=int(roles.sum()),
                      scored_primary_windows=int(support.displacement_05_to_20_common.sum()),
                      counts_by_early_group=support.group.value_counts().to_dict(),tables=table_checks,
                      python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,torch=torch.__version__,
                      training_updates=0,model_forward_calls=0,private_window_ledger_inputs=0,window_ledgers_saved=0)
        (work/"replay_receipt.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
        work.rename(args.out)
    print("Matched all seven frozen tables, including the confirmed-pair and coordinate-precision analyses.")


if __name__ == "__main__":
    main()
