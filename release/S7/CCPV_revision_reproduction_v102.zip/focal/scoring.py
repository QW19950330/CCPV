"""Score the frozen focal player paths and aggregate observed errors by fixture and seed."""

import io
import hashlib
import numpy as np
import pandas as pd
import torch

PATHS = ["natural", "first_A", "first_provenance_only_A"]
COMPARISONS = {"edit_minus_sham": (1, 2), "edit_minus_natural": (1, 0), "sham_minus_natural": (2, 0)}
ENDPOINTS = {"displacement_05_to_20": (4, 19), "displacement_05_to_10": (4, 9), "position_20": (None, 19)}


def read_checked(path, expected):
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError(f"File identity mismatch: {path}")
    return data


def pull_paths(manifest, p, slots, predictions):
    n = len(slots)
    path_ids = [manifest["paths"].index(name) for name in PATHS]
    for cell in manifest["cells"]:
        name = cell["cell"]
        coords = np.full((n, 3, 20, 2), np.nan, dtype="float64")
        available = np.zeros((n, 3, 20), dtype=bool)
        complete = np.zeros((n, 3), dtype=bool)
        start = 0
        for item in cell["blocks"]:
            data = read_checked(predictions / name / item["path"], item["sha256"])
            with np.load(io.BytesIO(data), allow_pickle=False) as z:
                count = len(z["match_ids"])
                rr = np.arange(count)
                section = slice(start,start + count)
                np.testing.assert_array_equal(z["source_indices"], p["source_indices"][section])
                np.testing.assert_array_equal(z["match_ids"], p["match_ids"][section])
                np.testing.assert_array_equal(z["actor_slots"], slots[section])
                aa = np.maximum(slots[section],0)
                state, support = z["states"], z["support"]
                for k, path in enumerate(path_ids):
                    coords[section,k] = state[rr,path,:,aa,:2]
                    available[section,k] = support[rr,path,:,aa]
                complete[section] = (z["status"][:,path_ids] == "COMPLETED") & (z["completed_steps"][:,path_ids] == 20)
            start += count
        assert start == n
        yield name, coords, available, complete


def classify(p, truth, offball, make_commands):
    n = len(p["match_ids"])
    i = np.arange(n)
    slots = p["operator_candidate_slots"][:,0]
    actor = np.maximum(slots,0)
    for field in ("source_indices","match_ids","source_period","entity_ids"):
        np.testing.assert_array_equal(p[field],truth[field])
    np.testing.assert_array_equal(p["source_frame_ids"][:,-1,None]+np.arange(1,21),truth["future_frame_ids"])
    eligible = (slots >= 0) & ~p["technical_unsupported"]
    assert np.all(slots[eligible] < 22)
    assert np.all(p["entity_ids"][i[eligible],actor[eligible]] == p["operator_candidate_ids"][eligible,0])
    hist = p["history_states"]
    valid = eligible & p["history_valid"][i,-1,actor] & p["history_position_valid"][i,-1,actor]
    xy0 = hist[i,-1,actor,:2].astype(float)
    v0 = hist[i,-1,actor,2:].astype(float)
    selected = np.flatnonzero(valid)
    registries = [{"entity_ids":a.tolist()} for a in p["entity_ids"][selected]]
    targets = p["operator_candidate_ids"][selected].tolist()
    commands = make_commands(torch.from_numpy(hist[selected]),registries,targets)[:,0].numpy()
    vx = v0[selected]
    speed = np.linalg.norm(vx,axis=1)
    delta = np.tile([0.1,0.0],(len(vx),1))
    # Use the operator's float32 decision at its cutoff for an exact boundary case.
    moving = torch.linalg.vector_norm(torch.from_numpy(hist[selected,-1,actor[selected],2:]),dim=1).numpy() >= 0.1
    delta[moving] = 0.1 * np.column_stack((-vx[moving,1],vx[moving,0])) / speed[moving,None]
    np.testing.assert_allclose(commands,vx+delta,rtol=0,atol=1e-6)
    command = np.full_like(v0,np.nan)
    command[selected] = commands
    y = truth["positions"][i,:,actor,:].astype(float)
    tv = truth["position_valid"][i,:,actor]
    early = valid & tv[:,1]
    measured = (y[:,1]-xy0)/0.2
    dist_edit = np.linalg.norm(measured-command,axis=1)
    dist_initial = np.linalg.norm(measured-v0,axis=1)
    dist_edit[~early]=np.nan
    dist_initial[~early]=np.nan
    gap = dist_initial - dist_edit
    group = np.full(n,"tie",dtype="U20")
    group[~early]="unclassified"
    group[gap > 1e-6]="closer_edit"
    group[gap < -1e-6]="closer_initial"
    df = pd.DataFrame({"row":i,"fixture":p["match_ids"],"has_actor":eligible,"valid_t0":valid,
                       "observed_02":tv[:,1]&eligible,"group":group,"dist_edit":dist_edit,
                       "dist_initial":dist_initial,"within_05":np.minimum(dist_edit,dist_initial)<=0.5,
                       "offball":offball})
    return df,slots,y,tv


def evaluate(p, truth, manifest, predictions, offball, make_commands, out):
    base,slots,y,tv = classify(p,truth,offball,make_commands)
    assert len(base)==4992 and base.fixture.nunique()==4
    out.mkdir(exist_ok=False)
    masks,errors = {},{}
    for cell,z,sup,complete in pull_paths(manifest,p,slots,predictions):
        base[cell+"_complete"]=complete.all(1)
        for metric,(a,b) in ENDPOINTS.items():
            prediction,target = z[:,:,b], y[:,b]
            valid=tv[:,b] & sup[:,:,b].all(1) & complete.all(1)
            if a is not None:
                prediction=prediction-z[:,:,a]
                target=target-y[:,a]
                valid &= tv[:,a] & sup[:,:,a].all(1)
            error=np.linalg.norm(prediction-target[:,None],axis=-1)
            assert np.isfinite(error[valid]).all()
            errors[cell,metric]=error
            masks[cell,metric]=valid
    cells=[c["cell"] for c in manifest["cells"]]
    assert len(cells)==6 and cells[0]=="CV_s-1"
    base["all_complete"]=base[[c+"_complete" for c in cells]].all(axis=1)
    for metric,(a,b) in ENDPOINTS.items():
        base[metric+"_observed"]=base.has_actor & tv[:,b] & (tv[:,a] if a is not None else True)
        base[metric+"_common"]=np.logical_and.reduce([masks[c,metric] for c in cells]) & base.group.isin(["closer_edit","closer_initial"])
    fmeans=[]
    local_tables=[]
    for metric in ENDPOINTS:
        for cell in cells:
            sub=base.loc[base[metric+"_common"],["row","fixture","group","within_05","offball"]].copy()
            sub["cell"],sub["metric"]=cell,metric
            vals=errors[cell,metric][sub.row]
            for k,path in enumerate(PATHS):
                sub[path]=vals[:,k]
            for comp,(i,j) in COMPARISONS.items():
                sub[comp]=vals[:,i]-vals[:,j]
            local_tables.append(sub)
            measures=PATHS+list(COMPARISONS)
            for pop,selected in (("all",sub),("within_05",sub[sub.within_05]),("offball",sub[sub.offball])):
                for (fixture,group),part in selected.groupby(["fixture","group"]):
                    fmeans.append(dict(metric=metric,cell=cell,scope=pop,fixture=fixture,group=group,
                        n=len(part),**{m:part[m].mean() for m in measures}))
    details=pd.concat(local_tables,ignore_index=True)
    fixture=pd.DataFrame(fmeans)
    fixture.to_csv(out/"fixture.csv",index=False)
    seed_rows=[]
    for (metric,scope,cell),part in fixture.groupby(["metric","scope","cell"]):
        for measure in measures:
            pivot=part.pivot(index="fixture",columns="group",values=measure).reindex(index=sorted(base.fixture.unique()),columns=["closer_edit","closer_initial"])
            pivot["group_difference"]=pivot.closer_edit-pivot.closer_initial
            for grp in pivot:
                series=pivot[grp]
                seed_rows.append(dict(metric=metric,scope=scope,cell=cell,measure=measure,group=grp,nfixtures=int(series.count()),
                                      mean=series.mean() if series.count()==4 else np.nan))
    seeds=pd.DataFrame(seed_rows)
    seeds.to_csv(out/"seeds.csv",index=False)
    summary=[]
    for key,part in seeds.groupby(["metric","scope","measure","group"]):
        cv=part[part.cell==cells[0]]["mean"].iloc[0]
        neural=part[part.cell!=cells[0]]["mean"]
        summary.append(dict(zip(["metric","scope","measure","group"],key))|dict(D_mean=neural.mean(skipna=False),
            D_seed_sd=neural.std(skipna=False),CV=cv,D_minus_CV=neural.mean(skipna=False)-cv,valid_seeds=int(neural.count())))
    pd.DataFrame(summary).to_csv(out/"summary.csv",index=False)
    coverage=[]
    for mid,batch in base.groupby("fixture"):
        for group,part in list(batch.groupby("group"))+[("planned",batch)]:
            coverage.append(dict(fixture=mid,group=group,n=len(part),eligible_actor=int(part.has_actor.sum()),
                valid_t0=int(part.valid_t0.sum()),position_02=int(part.observed_02.sum()),complete_all=int(part.all_complete.sum()),
                median_distance_to_command=part.dist_edit.median() if part.dist_edit.notna().any() else np.nan,
                median_distance_to_initial=part.dist_initial.median() if part.dist_initial.notna().any() else np.nan,
                **{m:int(part[m+"_common"].sum()) for m in ENDPOINTS}))
    pd.DataFrame(coverage).to_csv(out/"coverage.csv",index=False)
    return base, details
