# Early movement and later displacement of the edited player

This evaluation asks whether the edited trajectory predicts the focal player’s subsequent recorded displacement more accurately than a sham trajectory. It uses four previously examined Australian fixtures, five frozen neural models, and one constant-velocity baseline. Each fixture receives equal weight. The groups use movement observed after the decision. Only the action that actually occurred has a measured outcome.

## Inputs

Use the public CCPV reproduction instructions to build the tracking prefixes, generate all 936 forecast blocks with the clean weights, and recover the directly detected future positions after prediction freeze. The script checks the forecast manifest, its selection, the truth receipt, the ordered block index and each block’s SHA-256. Use the exact source versions linked below.

| Argument | Expected input |
|---|---|
| `--public-repo` | CCPV source checkout at commit `e63b1a380e401e82760c9c0e5ab0d4ebef339f23`, including its released intervention operator. |
| `--prefix` | Reconstructed `test_prefixes.npz` containing all 4,992 windows in source order. |
| `--predictions` | Full `run_clean_diagnostic.py run --all-planned` output, including the six cell directories, `selection.json` and `completion.json`. |
| `--truth` | `detected_player_truth.npz`, accompanied by the `completion.json` from the same prediction freeze. |
| `--skillcorner-root` | The SkillCorner Open Data checkout at `4340d274572876239c154c90bc507a9b3250a656`, containing the eight match metadata and complete tracking files indexed in `references.json`. Tracking files must contain JSON lines rather than Git LFS pointers. |
| `--out` | A new directory for the seven aggregate tables and one replay receipt. |

[Public CCPV acquisition, inference and truth-recovery instructions](https://github.com/QW19950330/CCPV/tree/e63b1a380e401e82760c9c0e5ab0d4ebef339f23) · [Pinned SkillCorner Open Data release](https://github.com/SkillCorner/opendata/tree/4340d274572876239c154c90bc507a9b3250a656)

## Run

Use Python 3.11 with NumPy 1.26.4, pandas 2.3.1 and PyTorch 2.7.0. The scoring command uses CPU, reads local files, and performs no model forwards or training updates. Run it from the directory containing this README, substituting your own input locations.

```sh
python -B replay.py --public-repo CCPV_CHECKOUT --prefix PREFIX/test_prefixes.npz --predictions FULL_FORECASTS --truth TRUTH/detected_player_truth.npz --skillcorner-root SKILLCORNER_CHECKOUT --out focal_results
```

## What is scored

The released float32 operator yields the edited velocity. Early observed velocity comes from positions at 0 and 0.2 s. A window enters the group closer to the edited or the initial velocity if the difference between the two distances exceeds 0.000001 m/s. The primary outcome compares predicted and observed displacement between 0.5 and 2.0 s on common support across the three paths and six cells. A negative edit-minus-sham difference means lower observed error for the edited path. The two secondary outcomes are displacement from 0.5 to 1.0 s and absolute position at 2.0 s. Distances use the standardized 105 × 68 m pitch.

The `all` stratum and the subset within 0.5 m/s of either candidate velocity use only the prefixes, truth and public operator. The separate `offball` stratum checks both selected players against the source roster and the unique tracking record at the decision frame. Both players must belong to the possession team, and that team’s identified possessor must be a different player. An unknown possessor or an inconsistent team label does not confirm the pair. The label describes instantaneous possession. The procedure neither uses off-ball-run event annotations nor assumes that either player made a tactical run.

For the precision diagnostic, the recorded command, initial velocity, later endpoint and all model paths stay fixed. Each early position can vary by ±0.005, ±0.010 or ±0.020 standardized m on each axis. A window is retained if every position combination leaves it on the same side of the two-velocity decision boundary. The calculation verifies the analytic bound at all four corners of the corresponding velocity-error rectangle. These bounds describe scenarios, not measured tracking precision.

## Outputs

`results/coverage.csv` lists denominators and distances by fixture. `results/fixture.csv`, `results/seeds.csv` and `results/summary.csv` contain the three endpoints, three population strata, and comparisons among the natural, edited and sham paths. `position_precision/fixture.csv`, `position_precision/seeds.csv` and `position_precision/summary.csv` contain the three precision scenarios. Missing four-fixture means remain missing. The neural standard deviation is the sample standard deviation of the five seed means.

The command writes aggregate outputs only, and compares every column and every row in each CSV against the seven historical reference digests after standardizing newline characters. The replay receipt also checks the regenerated early-group assignments, the 4,992 binary role classifications and the eight provider source digests. A successful check has 498 confirmed pairs before endpoint filtering and 3,907 windows for the primary endpoint. The `verified/` directory contains the aggregate output of the tested run and its receipt. The package omits player-level observations, paths, and window-level ledgers.
