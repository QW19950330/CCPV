"""Check focal group assignments under bounded perturbations of the early coordinates."""
import io
import itertools
import numpy as np
import pandas as pd
import torch

def evaluate_precision(prefix, truth, support, details, make_commands, out):
    index = support.loc[support.displacement_05_to_20_common,"row"].to_numpy()
    slots = prefix["operator_candidate_slots"][index,0]
    history = prefix["history_states"][index]
    ids = prefix["entity_ids"][index]
    targets = prefix["operator_candidate_ids"][index].tolist()
    cmd = make_commands(torch.from_numpy(history),[{"entity_ids": r.tolist()} for r in ids],targets)[:,0].numpy().astype(float)
    # The historical sensitivity analysis read the primary CSV with pandas' default
    # float parser. Preserve that rounding step in memory without writing a window ledger.
    all_errors = pd.read_csv(io.StringIO(details[["row","metric","cell","fixture","group","edit_minus_sham"]].to_csv(index=False)))
    xyv=history[np.arange(len(index)),-1,slots].astype(float)
    v=(truth["positions"][index,1,slots].astype(float)-xyv[:,:2])/0.2
    v0=xyv[:,2:]
    axes=cmd-v0
    axes/=np.linalg.norm(axes,axis=1)[:,None]
    signed=((v-0.5*(cmd+v0))*axes).sum(axis=1)
    np.testing.assert_array_equal(signed>0,support.loc[index,"group"].to_numpy()=="closer_edit")
    primary=all_errors[all_errors.metric=="displacement_05_to_20"]
    out.mkdir(exist_ok=False)
    fixtures=[]
    seeds=[]
    summary=[]
    for eps in [0.005,0.010,0.020]:
        vel_error=2*eps/0.2
        mask=np.abs(signed)>vel_error*np.abs(axes).sum(axis=1)
        # Re-evaluate Euclidean distances directly at each extremal velocity.
        corners=[]
        for dx,dy in itertools.product((-1,1),repeat=2):
            vv=v+np.array([dx,dy])*vel_error
            dist_delta=np.linalg.norm(vv-v0,axis=1)-np.linalg.norm(vv-cmd,axis=1)
            corners.append(np.where(signed>0,dist_delta>0,dist_delta<0))
        np.testing.assert_array_equal(mask,np.logical_and.reduce(corners))
        retained=primary[primary.row.isin(index[mask])]
        table=retained.groupby(["cell","fixture","group"]).edit_minus_sham.agg(["size","mean"]).reset_index()
        table["epsilon_m"]=eps;fixtures.append(table)
        for group in ("closer_edit","closer_initial"):
            x=table[table.group==group]
            values={}
            for name in primary.cell.unique():
                t=x[x.cell==name]
                value=t["mean"].mean() if len(t)==4 else np.nan
                values[name]=value
                seeds.append(dict(epsilon_m=eps,group=group,cell=name,windows=int(t["size"].sum()),fixtures=len(t),mean=value))
            neural=[v for k,v in values.items() if k!="CV_s-1"]
            summary.append(dict(epsilon_m=eps,group=group,windows=int(x[x.cell=="CV_s-1"]["size"].sum()),
                                D_mean=np.mean(neural),D_seed_sd=np.std(neural,ddof=1),CV=values["CV_s-1"]))
    pd.concat(fixtures).to_csv(out/"fixture.csv",index=False)
    pd.DataFrame(seeds).to_csv(out/"seeds.csv",index=False)
    pd.DataFrame(summary).to_csv(out/"summary.csv",index=False)
