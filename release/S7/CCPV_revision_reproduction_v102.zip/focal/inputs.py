"""Verify public clean-weight replay inputs and the ordered forecast inventory."""

import hashlib
import io
import json
from pathlib import Path

import numpy as np

CELLS = ["CV_s-1"] + [f"D_coupled_ar_s{i}" for i in range(5)]
PREFIX = "a14904ed5a215805ce390fa0885b99e2e49752da096d47b119ba0019b0b8b656"
TRUTH = "1d76d5dfcde855cb932871211e673449c9c4cd94738ce80548c22235a92036b8"
CLEAN_BINDING = "d4ba1fa402cbff99424c006fd44dfb7f50a558e05443b0e4eb7dc0be285fa85f"
BLOCK_INDEX = "94eab25ddd28fe111c189c95e03525c9f5b49a60a8ea8b800ec3cc92edad7a2b"
GROUPS_DIGEST = "79f2e9f093a5c58df8a7c37890d7aa3038430ebb966962f075b5d7949b7ac520"
PUBLIC_OPERATOR = Path("bundles/diagnostic_portable/runtime_sources/"
                       "CCPV_reviewer_validation_program_20261026/full_intervention")
OPERATOR_DIGEST = "39c28628637461e5e3d90f802ea901ff7eed86e64e07fe7c1b4e49d2c1a88d9d"
PATHS = ["natural", "none_every_step", "first_A", "persistent_A",
         "maintained_v0_A", "first_provenance_only_A"]


def digest(content):
    return hashlib.sha256(content).hexdigest()


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def verified_arrays(path, expected):
    raw = path.read_bytes()
    require(digest(raw) == expected, f"Input digest mismatch: {path}")
    with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
        return dict(archive)


def load_clean_manifest(folder, truth_path):
    raw = (folder / "completion.json").read_bytes()
    spec = json.loads(raw)
    manifest_hash = digest(raw)
    require(spec["execution_kind"] == "new_explicit_clean_npz_binding"
            and spec["status"] == "COMPLETE_FIXED4992_SIX_CELLS_SIX_PATHS"
            and spec["new_training_updates"] == 0 and spec["future_truth_read"] is False
            and spec["full_cohort"] is True and spec["planned_source_windows"] == 4992
            and spec["binding_sha256"] == CLEAN_BINDING, "Expected the complete frozen clean run")
    require(spec["paths"] == PATHS and [c["cell"] for c in spec["cells"]] == CELLS,
            "Unexpected prediction cell or path order")
    selection = json.loads((folder / "selection.json").read_bytes())
    require(selection["prefix_sha256"] == PREFIX and selection["binding_sha256"] == CLEAN_BINDING
            and selection["all_planned"] is True and selection["row_positions"] == list(range(4992)),
            "Incomplete or mismatched prediction selection")
    truth_receipt = json.loads((truth_path.parent / "completion.json").read_bytes())
    require(truth_receipt["prediction_completion_sha256"] == manifest_hash
            and truth_receipt["status"] == "COMPLETE_DETECTED_ONLY_PLAYER_TRUTH_AFTER_PREDICTION_FREEZE"
            and truth_receipt["prepared_prefix_sha256"] == PREFIX and truth_receipt["sha256"] == TRUTH
            and truth_receipt["path"] == truth_path.name, "Prediction and detected-truth receipts do not match")
    index = [[cell["cell"], [[b["path"], b["sha256"]] for b in cell["blocks"]]]
             for cell in spec["cells"]]
    require(digest(json.dumps(index, separators=(",", ":")).encode()) == BLOCK_INDEX,
            "The ordered index of 936 prediction blocks differs from the reference")
    return spec, manifest_hash


