"""Resolve both candidate players' same-frame team and possession context."""
import hashlib
import json
import re

import numpy as np

from inputs import digest, require


FRAME = re.compile(rb'"frame"\s*:\s*(\d+)')


def identifier(value):
    return "" if value is None else str(value).strip()


def possession_at_frames(path, requested, expected_digest):
    frame_numbers = {frame for _, frame in requested}
    found = {}
    content_hash = hashlib.sha256()
    with path.open("rb") as stream:
        for line in stream:
            content_hash.update(line)
            match = FRAME.search(line)
            if match is None or int(match[1]) not in frame_numbers:
                continue
            record = json.loads(line)
            if record.get("period") is None:
                continue
            key = (int(record["period"]), int(record["frame"]))
            if key in requested:
                require(key not in found, "Duplicate period/frame for a requested tracking frame")
                found[key] = record.get("possession") or {}
    require(content_hash.hexdigest() == expected_digest, "Provider tracking file digest mismatch")
    require(set(found) == requested, "Missing provider t0 frame")
    return found


def reconstruct(prefix, raw_root, reference):
    flags = np.zeros(len(prefix["match_ids"]), dtype=np.uint8)
    pins = reference["provider_files"]
    checked = set()
    for fixture in np.unique(prefix["match_ids"]):
        rows = np.flatnonzero(prefix["match_ids"] == fixture)
        fixture_id = str(fixture).split(":")[-1]
        base = f"data/matches/{fixture_id}/{fixture_id}"
        metadata = base + "_match.json"
        tracking = base + "_tracking_extrapolated.jsonl"
        raw_meta = (raw_root / metadata).read_bytes()
        require(digest(raw_meta) == pins[metadata], "Provider match metadata digest mismatch")
        roster_data = json.loads(raw_meta)
        home = identifier(roster_data["home_team"]["id"])
        away = identifier(roster_data["away_team"]["id"])
        roster = {identifier(player["id"]): identifier(player["team_id"])
                  for player in roster_data["players"]}
        require(len(roster) == len(roster_data["players"]), "Roster IDs are not unique")
        keys = [(int(prefix["source_period"][i]), int(prefix["source_frame_ids"][i,-1])) for i in rows]
        found = possession_at_frames(raw_root / tracking, set(keys), pins[tracking])
        for row, key in zip(rows, keys):
            slots = prefix["operator_candidate_slots"][row]
            ids = [identifier(value) for value in prefix["operator_candidate_ids"][row]]
            if min(slots) < 0:
                continue
            for source_id, slot in zip(ids, slots):
                require(source_id == identifier(prefix["entity_ids"][row, slot]), "Candidate ID/slot mismatch")
            possession = found[key]
            team = {"home team": home, "away team": away}.get(possession.get("group"))
            carrier = identifier(possession.get("player_id"))
            flags[row] = (team in (home, away) and roster.get(carrier) == team and
                          carrier not in ids and all(roster.get(player) == team for player in ids))
        checked.update([metadata, tracking])
    require(checked == set(pins), "Incomplete four-match provider inventory")
    require(digest(flags.tobytes()) == reference["offball_bool_uint8_sha256"], "Role mask digest mismatch")
    return flags.astype(bool)
