"""Verify the released aggregate rows with the Python standard library."""
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent / "results"
GROUPS = ("closer_edit", "closer_initial")
CV = "CV_s-1"
NEURAL = tuple(f"D_coupled_ar_s{i}" for i in range(5))


def read(name):
    with (ROOT / name).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def check_equal(actual, expected):
    if math.isnan(expected):
        assert math.isnan(actual)
    else:
        assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-14), (actual, expected)


def number(txt):
    return float(txt) if txt else float("nan")


def main():
    coverage = {(r["fixture"], r["group"]): r for r in read("coverage.csv")}
    assert len(coverage) == 16
    for name, target in (("planned", 4992), ("nearest_selected", 4945), ("near_scorable", 3950),
                         ("far_scorable", 3737), ("both_scorable", 3420)):
        assert sum(int(r[name]) for r in coverage.values()) == target
    fx = defaultdict(dict)
    for r in read("fixture.csv"):
        cell, scope, match, grp, measure = [r[k] for k in ("cell", "scope", "fixture", "group", "measure")]
        values = fx[cell, scope, measure, grp]
        assert match not in values
        values[match] = number(r["value"])
        expected = coverage[match, grp]["near_scorable" if scope == "nearest" else "both_scorable"]
        assert int(r["n"]) == int(expected)
    seed_table = defaultdict(dict)
    for r in read("seeds.csv"):
        cell, scope, measure, grp = [r[k] for k in ("cell", "scope", "measure", "group")]
        if grp in GROUPS:
            vals = list(fx[cell, scope, measure, grp].values())
        else:
            assert grp == "group_difference"
            a, b = (fx[cell, scope, measure, g] for g in GROUPS)
            assert a.keys() == b.keys()
            vals = [v-b[k] for k, v in a.items()]
        assert len(vals) == 4 and int(r["fixtures"]) == sum(math.isfinite(v) for v in vals)
        obs = number(r["value"])
        check_equal(obs, statistics.mean(vals))
        cells = seed_table[scope, measure, grp]
        assert cell not in cells
        cells[cell] = obs
    seen = set()
    for r in read("summary.csv"):
        key = tuple(r[k] for k in ("scope", "measure", "group"))
        assert key not in seen
        seen.add(key)
        vals = seed_table[key]
        assert set(vals) == {*NEURAL, CV}
        d = [vals[c] for c in NEURAL]
        check_equal(number(r["D_mean"]), statistics.mean(d))
        sd = statistics.stdev(d) if all(math.isfinite(v) for v in d) else float("nan")
        check_equal(number(r["D_seed_sd"]), sd)
        check_equal(number(r["CV"]), vals[CV])
    assert len(seen) == len(seed_table) == 117
    assert sum(map(len, fx.values())) == 1872
    print("Verified 16 coverage rows, 1,872 fixture rows, 702 seed rows and 117 five-seed summaries.")


if __name__ == "__main__":
    main()
