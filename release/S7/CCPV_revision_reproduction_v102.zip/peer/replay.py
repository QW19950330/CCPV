"""Rebuild the early groups and score the full public-route inference outputs."""

import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile

import numpy as np
import pandas as pd
import torch


from model_response import CELLS, evaluate


PREFIX = "a14904ed5a215805ce390fa0885b99e2e49752da096d47b119ba0019b0b8b656"
TRUTH = "1d76d5dfcde855cb932871211e673449c9c4cd94738ce80548c22235a92036b8"
CLEAN_BINDING = "d4ba1fa402cbff99424c006fd44dfb7f50a558e05443b0e4eb7dc0be285fa85f"
BLOCK_INDEX = "94eab25ddd28fe111c189c95e03525c9f5b49a60a8ea8b800ec3cc92edad7a2b"
GROUPS_DIGEST = "79f2e9f093a5c58df8a7c37890d7aa3038430ebb966962f075b5d7949b7ac520"
PUBLIC_OPERATOR = Path("bundles/diagnostic_portable/runtime_sources/"
                       "CCPV_reviewer_validation_program_20261026/full_intervention")
OPERATOR_DIGEST = "39c28628637461e5e3d90f802ea901ff7eed86e64e07fe7c1b4e49d2c1a88d9d"
PATHS = ["natural", "none_every_step", "first_A", "persistent_A",
         "maintained_v0_A", "first_provenance_only_A"]
REFERENCE_TABLES = {
    "coverage.csv": "466aa234323efd29e6f8cfaec37f8d4252d2784b45430d83631d69d993a3f6eb",
    "fixture.csv": "4c0260c31628fc1a0a19c000a8aad2e200c4d8bd3705dddbb3f4f2e2ad4ac923",
    "seeds.csv": "5b75e6441ce38aebc3c560eb870123b7267a31f802577cc25e91e123b0781d28",
    "summary.csv": "b1d314d62c1fa1f151888d96d3cc7ae5353395b72e80e3de007c6e1f76e5ae56",
}


def digest(content):
    return hashlib.sha256(content).hexdigest()


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def verified_arrays(path, expected):
    raw = path.read_bytes()
    require(digest(raw) == expected, f"Input digest mismatch: {path}")
    with np.load(io.BytesIO(raw), allow_pickle=False) as archive:
        return dict(archive)


def load_clean_manifest(folder, truth_path):
    raw = (folder / "completion.json").read_bytes()
    spec = json.loads(raw)
    manifest_hash = digest(raw)
    require(spec["execution_kind"] == "new_explicit_clean_npz_binding"
            and spec["status"] == "COMPLETE_FIXED4992_SIX_CELLS_SIX_PATHS"
            and spec["new_training_updates"] == 0 and spec["future_truth_read"] is False
            and spec["full_cohort"] is True and spec["planned_source_windows"] == 4992
            and spec["binding_sha256"] == CLEAN_BINDING, "Expected the complete frozen clean run")
    require(spec["paths"] == PATHS and [c["cell"] for c in spec["cells"]] == CELLS,
            "Unexpected prediction cell or path order")
    selection = json.loads((folder / "selection.json").read_bytes())
    require(selection["prefix_sha256"] == PREFIX and selection["binding_sha256"] == CLEAN_BINDING
            and selection["all_planned"] is True and selection["row_positions"] == list(range(4992)),
            "Incomplete or mismatched prediction selection")
    truth_receipt = json.loads((truth_path.parent / "completion.json").read_bytes())
    require(truth_receipt["prediction_completion_sha256"] == manifest_hash
            and truth_receipt["status"] == "COMPLETE_DETECTED_ONLY_PLAYER_TRUTH_AFTER_PREDICTION_FREEZE"
            and truth_receipt["prepared_prefix_sha256"] == PREFIX and truth_receipt["sha256"] == TRUTH
            and truth_receipt["path"] == truth_path.name, "Prediction and detected-truth receipts do not match")
    index = [[cell["cell"], [[b["path"], b["sha256"]] for b in cell["blocks"]]]
             for cell in spec["cells"]]
    require(digest(json.dumps(index, separators=(",", ":")).encode()) == BLOCK_INDEX,
            "The ordered index of 936 prediction blocks differs from the reference")
    return spec, manifest_hash


def reconstruct_groups(prefix, truth, public_repo):
    operator = public_repo / PUBLIC_OPERATOR
    raw = (operator / "operator_adapter.py").read_bytes()
    require(digest(raw) == OPERATOR_DIGEST, "The public inference operator differs from the reference")
    sys.path.insert(0, str(operator))
    from operator_adapter import make_commands

    rows = np.arange(len(prefix["match_ids"]))
    slot = prefix["operator_candidate_slots"][:, 0]
    actor = np.maximum(slot, 0)
    eligible = (slot >= 0) & ~prefix["technical_unsupported"]
    selected = np.flatnonzero(eligible & prefix["history_valid"][rows, -1, actor]
                              & prefix["history_position_valid"][rows, -1, actor])
    np.testing.assert_array_equal(prefix["entity_ids"][selected, actor[selected]],
                                  prefix["operator_candidate_ids"][selected, 0])
    for field in ("source_indices", "match_ids", "source_period", "entity_ids"):
        np.testing.assert_array_equal(prefix[field], truth[field])
    np.testing.assert_array_equal(prefix["source_frame_ids"][:, -1, None] + np.arange(1, 21),
                                  truth["future_frame_ids"])

    history = prefix["history_states"][selected]
    registries = [{"entity_ids": ids.tolist()} for ids in prefix["entity_ids"][selected]]
    targets = prefix["operator_candidate_ids"][selected].tolist()
    commanded = make_commands(torch.from_numpy(history), registries, targets)[:, 0].numpy()
    at_start = history[np.arange(len(selected)), -1, actor[selected]].astype(np.float64)
    detected = truth["position_valid"][selected, 1, actor[selected]]
    at_two_frames = truth["positions"][selected, 1, actor[selected]].astype(np.float64)
    observed_velocity = (at_two_frames - at_start[:, :2]) / 0.2
    gap = (np.linalg.norm(observed_velocity - at_start[:, 2:], axis=1)
           - np.linalg.norm(observed_velocity - commanded, axis=1))
    require(np.isfinite(gap[detected]).all(), "Missing velocity for a detected early endpoint")
    group = np.full(len(rows), "unclassified", dtype="U20")
    group[selected[detected]] = "tie"
    group[selected[detected & (gap > 1e-6)]] = "closer_edit"
    group[selected[detected & (gap < -1e-6)]] = "closer_initial"
    groups = pd.DataFrame({"row": rows, "fixture": prefix["match_ids"], "group": group})
    require(digest(groups.to_csv(index=False, lineterminator="\n").encode()) == GROUPS_DIGEST,
            "Regenerated early classification differs from the frozen reference")
    return groups


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--truth", type=Path, required=True)
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--public-repo", type=Path, default=Path.cwd())
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    require(__debug__, "Run without Python optimization; the scoring code uses assertions")
    require(not args.out.exists(), f"Output already exists: {args.out}")
    prefix = verified_arrays(args.prefix, PREFIX)
    truth = verified_arrays(args.truth, TRUTH)
    spec, manifest_hash = load_clean_manifest(args.predictions, args.truth)
    groups = reconstruct_groups(prefix, truth, args.public_repo.resolve())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out.parent) as temp:
        out = Path(temp) / "results"
        evaluate(prefix, truth, spec, groups, args.predictions, out)
        tables = {}
        for name, expected in REFERENCE_TABLES.items():
            content = (out / name).read_bytes().replace(b"\r\n", b"\n")
            actual = digest(content)
            require(actual == expected, f"Aggregate CSV content differs from reference: {name}")
            tables[name] = {"lf_sha256": actual, "data_rows": len(content.splitlines()) - 1}
        receipt = {"status": "all_four_aggregate_tables_match", "new_training_updates": 0,
                   "prefix_sha256": PREFIX, "truth_sha256": TRUTH, "prediction_receipt_sha256": manifest_hash,
                   "ordered_936_block_index_sha256": BLOCK_INDEX, "public_operator_sha256": OPERATOR_DIGEST,
                   "groups_lf_sha256": GROUPS_DIGEST, "counts_by_early_group": groups.group.value_counts().to_dict(),
                   "tables": tables, "numpy": np.__version__, "pandas": pd.__version__, "torch": torch.__version__}
        (out / "replay_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        out.rename(args.out)
    print("Reconstructed all 4,992 group assignments and matched the four reference tables.")


if __name__ == "__main__":
    main()
