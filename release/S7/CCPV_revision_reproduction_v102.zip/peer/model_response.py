"""Score uncommanded teammates against disjoint, directly observed future frames."""

import hashlib
import io

import numpy as np
import pandas as pd


GROUPS = ("closer_edit", "closer_initial")
CELLS = ["CV_s-1"] + [f"D_coupled_ar_s{s}" for s in range(5)]


def bound(path, expected):
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError(f"File identity mismatch for {path}")
    return data


def select(p, t):
    for k in ("entity_ids", "match_ids", "source_indices", "source_period"):
        np.testing.assert_array_equal(t[k], p[k])
    np.testing.assert_array_equal(t["future_frame_ids"], p["source_frame_ids"][:, -1, None] + np.arange(1, 21))
    n = len(p["source_indices"])
    choice = np.full((n, 2), -1, dtype=int)
    metres = np.full((n, 2), np.nan)
    count = np.zeros(n, dtype=int)
    xy = p["history_states"][:, -1, :, :2].astype(float)
    source_valid = p["history_valid"][:, -1] & p["history_position_valid"][:, -1]
    for i, a in enumerate(p["operator_candidate_slots"][:, 0]):
        if a < 0 or p["technical_unsupported"][i]:
            continue
        assert a < 22 and source_valid[i,a]
        team, ids = p["provider_team_ids"][i], p["entity_ids"][i]
        assert team[a] == p["home_team_id"][i] and ids[a] == p["operator_candidate_ids"][i,0]
        options = []
        for j in range(22):
            if j == a or team[j] != team[a] or not source_valid[i,j]:
                continue
            if p["identity_status"][i,j] != "VERIFIED_SOURCE_PLAYER_TEAM" or np.count_nonzero(ids == ids[j]) != 1:
                continue
            distance = np.linalg.norm(xy[i,j] - xy[i,a])
            options.append((distance, int(ids[j]), j))
        count[i] = len(options)
        if not options:
            continue
        near, _, near_slot = min(options)
        choice[i,0], metres[i,0] = near_slot, near
        far, _, far_slot = min(options, key=lambda x: (-x[0], x[1]))
        if far_slot != near_slot:
            choice[i,1], metres[i,1] = far_slot, far
    return choice, metres, count


def observed(p, t, choice):
    rr = np.arange(len(choice))[:,None]
    slots = np.maximum(choice, 0)
    pos = t["positions"]
    valid = t["position_valid"]
    truth = pos[rr,19,slots].astype(float) - pos[rr,4,slots].astype(float)
    support = (choice >= 0) & valid[rr,19,slots] & valid[rr,4,slots]
    assert np.isfinite(truth[support]).all()
    return truth, support


def displacement_manifest(p, choice, run_spec, prediction_folder):
    path_ids = [run_spec["paths"].index(x) for x in ("first_A","first_provenance_only_A","natural")]
    n = len(choice)
    all_valid = np.ones((n, 2), dtype=bool)
    forecasts = {}
    for cell in run_spec["cells"]:
        name = cell["cell"]
        delta = np.full((n,2,3,2), np.nan)
        offset = 0
        for block in cell["blocks"]:
            with np.load(io.BytesIO(bound(prediction_folder/name/block["path"], block["sha256"])),allow_pickle=False) as z:
                size = len(z["match_ids"])
                section = slice(offset, offset+size)
                for k in ("match_ids","source_indices"):
                    np.testing.assert_array_equal(z[k], p[k][section])
                np.testing.assert_array_equal(z["actor_slots"],p["operator_candidate_slots"][section,0])
                slots = np.maximum(choice[section], 0)
                states, ok = z["states"], z["support"]
                complete = (z["status"] == "COMPLETED") & (z["completed_steps"] == 20)
                rr = np.arange(size)[:,None]
                for j, path in enumerate(path_ids):
                    start = states[rr,path,4,slots,:2].astype(float)
                    end = states[rr,path,19,slots,:2].astype(float)
                    delta[section,:,j] = end-start
                    all_valid[section] &= ok[rr,path,4,slots] & ok[rr,path,19,slots] & complete[:,path,None]
                offset += size
        assert offset == n
        forecasts[name] = delta
    assert set(forecasts) == set(CELLS)
    return forecasts, all_valid & (choice>=0)


def norm(x):
    return np.linalg.norm(x, axis=-1)


def peer_metrics(pred, y, mask):
    edit, sham, natural = [pred[:,:,k] for k in range(3)]
    err_edit, err_sham, err_natural = [norm(z-y) for z in (edit,sham,natural)]
    shift = edit-sham
    magnitude = norm(shift)
    diff = err_edit-err_sham
    assert np.all(np.abs(diff[mask]) <= magnitude[mask] + 1e-12)
    reduction = (2*((y-sham)*shift).sum(axis=-1) - magnitude**2)[mask]
    np.testing.assert_allclose((err_sham**2 - err_edit**2)[mask], reduction, rtol=1e-9, atol=1e-12)
    return {
        "edited_error":err_edit, "sham_error":err_sham, "natural_error":err_natural,
        "edit_minus_sham_error":diff, "abs_error_change":np.abs(diff),
        "sham_minus_natural_error":err_sham-err_natural, "response_m":magnitude,
        "edit_minus_reflected_error":err_edit-norm((sham-shift)-y),
        "fraction_exact_zero":magnitude==0, "fraction_over_1mm":magnitude>0.001,
        "fraction_over_1cm":magnitude>0.010,
    }


def assignment_metrics(pred,y):
    edit, sham = pred[:,:,0], pred[:,:,1]
    own = edit-sham
    swap = sham+own[:,::-1]
    d_obs = y[:,0]-y[:,1]
    d_edit, d_sham = edit[:,0]-edit[:,1], sham[:,0]-sham[:,1]
    return {
        "own_minus_swapped_error": (norm(edit-y)-norm(swap-y)).mean(axis=1),
        "relative_edit_minus_sham": norm(d_edit-d_obs)-norm(d_sham-d_obs),
        "relative_response_m":norm(d_edit-d_sham),
    }


def evaluate(p, t, run_spec, groups, prediction_folder, out):
    np.testing.assert_array_equal(groups.row,np.arange(4992))
    np.testing.assert_array_equal(groups.fixture,p["match_ids"])
    slots,distances,n_candidates = select(p,t)
    truth,tvalid = observed(p,t,slots)
    forecasts,valid = displacement_manifest(p,slots,run_spec,prediction_folder)
    mask = valid & tvalid & groups.group.isin(GROUPS).to_numpy()[:,None]
    dual = mask.all(axis=1)
    out.mkdir(exist_ok=False)
    ledger = groups.assign(n_candidates=n_candidates, near_slot=slots[:,0], far_slot=slots[:,1],
            near_distance_m=distances[:,0], far_distance_m=distances[:,1],
            near_truth=tvalid[:,0], far_truth=tvalid[:,1], near_paths=valid[:,0], far_paths=valid[:,1],
            near_scorable=mask[:,0], far_scorable=mask[:,1], both_scorable=dual)
    ledger.to_csv(out/"selection_local.csv.gz",index=False)
    coverage=[]
    for (fixture,group), part in ledger.groupby(["fixture","group"]):
        cover={k:int(part[k].sum()) for k in ["near_truth","far_truth","near_paths","far_paths","near_scorable","far_scorable","both_scorable"]}
        coverage.append(dict(fixture=fixture,group=group,planned=len(part),nearest_selected=int((part.near_slot>=0).sum()),
                distinct_pair_selected=int((part.far_slot>=0).sum()),**cover))
    pd.DataFrame(coverage).to_csv(out/"coverage.csv",index=False)
    rows=[]
    for name in CELLS:
        pred=forecasts[name]
        assert np.isfinite(pred[mask]).all()
        if name==CELLS[0]:
            np.testing.assert_array_equal(pred[:,:,0][mask],pred[:,:,1][mask])
            np.testing.assert_array_equal(pred[:,:,2][mask],pred[:,:,1][mask])
        m=peer_metrics(pred,truth,mask)
        both_metrics=assignment_metrics(pred,truth)
        scopes=[("nearest",mask[:,0],{k:v[:,0] for k,v in m.items()}),
                ("near_paired",dual,{k:v[:,0] for k,v in m.items()}),
                ("far_paired",dual,{k:v[:,1] for k,v in m.items()}),
                ("pair_assignment",dual,both_metrics),
                ("near_minus_far",dual,{k:m[k][:,0]-m[k][:,1] for k in ["edit_minus_sham_error","response_m","abs_error_change"]})]
        for scope,which,metrics in scopes:
            for fixture in sorted(groups.fixture.unique()):
                for group in GROUPS:
                    keep=which & (groups.fixture==fixture).to_numpy() & (groups.group==group).to_numpy()
                    for key,v in metrics.items():
                        assert np.isfinite(v[keep]).all()
                        rows.append(dict(cell=name,scope=scope,fixture=fixture,group=group,measure=key,n=int(keep.sum()),
                                      value=float(np.mean(v[keep])) if keep.any() else np.nan))
    frame = pd.DataFrame(rows)
    frame.to_csv(out/"fixture.csv",index=False)
    output=[]
    for (cell,scope,key),part in frame.groupby(["cell","scope","measure"]):
        f=part.pivot(index="fixture",columns="group",values="value")
        assert len(f)==4
        f["group_difference"]=f[GROUPS[0]]-f[GROUPS[1]]
        for g in (*GROUPS,"group_difference"):
            output.append(dict(cell=cell,scope=scope,measure=key,group=g,fixtures=int(f[g].count()),value=f[g].mean(skipna=False)))
    seed=pd.DataFrame(output)
    seed.to_csv(out/"seeds.csv",index=False)
    summary=[]
    for (scope,key,g),part in seed.groupby(["scope","measure","group"]):
        v=part.set_index("cell").value
        learn=v.loc[CELLS[1:]]
        summary.append(dict(scope=scope,group=g,measure=key,D_mean=learn.mean(skipna=False),D_seed_sd=learn.std(skipna=False),CV=v[CELLS[0]]))
    pd.DataFrame(summary).to_csv(out/"summary.csv",index=False)
    print("Scored",mask.sum(axis=0),"nearest/farthest rows;",int(dual.sum()),"matched distinct pairs",flush=True)
