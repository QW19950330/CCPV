# Reproduction code and aggregate results for the revision analyses

The four analyses below test predictions on recorded matches, responses to model inputs and the sensitivity of score allocations. They retain the paper's fixed matches, model seeds and endpoint definitions. Each component lists the data and model inputs it needs.

| Question | Entry point and reconstruction level |
|---|---|
| Did a different input velocity predict the edited player's subsequent displacement? | [Focal player](focal/README.md) rebuilds the early movement groups, the two-player possession roles and the measurement-precision analysis from source matches and frozen predictions. |
| Did the nearest teammate's forecast respond, and was it closer to the recorded movement? | [Uncommanded teammate](peer/README.md) reads the same frozen forecasts and independently scored future positions. It also includes a standard-library check of the aggregate tables. |
| Did neural propagation add information about later shot versus pass endings beyond current geometry? | [Possession endings](geometry_value/README.md) explains how to recover the recorded ending, compute the goal-distance and opening-angle features, and compare the stationary, constant-velocity and neural paths. |
| Did the allocated contributions depend on the reference, score scale or partner? | [Two-player attribution](attribution/README.md) provides separate entries for selection, simulated coalition scores and aggregation. The aggregate entry runs on the included fixture tables. |

The [four-match input guide](guide/README.md) gives commands to obtain the original source versions, rebuild the 20-match cache and 4,992 test prefixes, run the five frozen models and constant-velocity baseline, and recover detected player positions. The source tracking, event files and model execution arrays are obtained separately under their respective terms. Some upstream arrays for the attribution and possession-ending analyses remain historical inputs. Each component documents its required inputs and the starting point that was actually tested.

To check the archive contents after extraction, run the following from this directory with Python 3.11 or later.

```sh
python -B verify.py
python -B peer/verify_tables.py
python -I -B geometry_value/replay_aggregates.py
python -B attribution/replay.py aggregates --out ../attribution_check
```

For the scientific runs, use the package versions specified by the components. The reference computations used Python 3.11, NumPy 1.26.4, pandas 2.3.1, SciPy 1.11.1 and PyTorch 2.7.0. The outcome comparisons concern recorded possessions and shots. The matches provide no observed outcome for an alternative action that the players did not execute.

The earlier code and archival record have fixed identities. [Base code](https://github.com/QW19950330/CCPV/tree/e63b1a380e401e82760c9c0e5ab0d4ebef339f23) · [Base archives](https://doi.org/10.5281/zenodo.24370617)
