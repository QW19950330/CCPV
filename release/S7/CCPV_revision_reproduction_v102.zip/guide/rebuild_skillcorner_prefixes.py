"""I/O-only scaffold for pinned public raw20 -> historical cache -> fixed prefixes.
Never changes parser mathematics, source order, support, array values or expected guards.
"""
from pathlib import Path
import argparse, ast, datetime, hashlib, importlib.metadata, json, os, shutil, subprocess, sys, time

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):h.update(b)
    return h.hexdigest()

def read(path):return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def require(ok,message):
    if not ok:raise ValueError(message)

def write_new(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("x",encoding="utf-8") as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write("\n")

def safe_join(base,relative):
    require(isinstance(relative,str) and not Path(relative).is_absolute(),"Relative path required")
    result=(base/relative).resolve()
    require(result.is_relative_to(base.resolve()) and result!=base.resolve(),"Path escapes root")
    return result

def stamp(path):
    s=Path(path).stat()
    return {"bytes":s.st_size,"mtime_ns":s.st_mtime_ns}

def verified_plan(args):
    plan_path=Path(args.plan).resolve();require(sha(plan_path)==args.plan_sha256,"Plan SHA differs")
    plan=read(plan_path);job=plan_path.parent;workspace=job/"workspace"
    require(job==Path(plan["job_root"]).resolve(),"Relocated plan must be explicitly rebound, not silently accepted")
    require(sha(__file__)==plan["wrapper_sha256"],"Wrapper differs from sealed I/O scaffold")
    require(plan["git_commit"]=="e63b1a380e401e82760c9c0e5ab0d4ebef339f23","Public snapshot differs")
    require(plan["raw_source_root"]!=str(workspace),"Raw source and output must be distinct")
    for row in plan["source_files"]:
        q=safe_join(workspace,row["path"])
        require(q.is_file() and q.stat().st_size==row["bytes"] and sha(q)==row["sha256"],"Staged public source mismatch: "+row["path"])
        if q.suffix==".py":ast.parse(q.read_text(encoding="utf-8-sig"),filename=str(q))
    manifest=read(safe_join(workspace,plan["download_manifest"]))
    require(manifest["commit"]==plan["provider_revision"] and manifest["status"]=="COMPLETED","Provider pin/status differs")
    require(manifest["matches"]==plan["matches_in_original_order"],"Original 20-match order changed")
    require(len(manifest["files"])==83 and len(set(r["path"] for r in manifest["files"]))==83,"Wrong 83-file inventory")
    require([{"path":r["path"],"kind":r["kind"],"bytes":r["expected_bytes"],"sha256":r["sha256"]} for r in manifest["files"]]==plan["all_83_source_pins"],"Source inventory changed")
    selected=[r for r in manifest["files"] if r["kind"] in ("metadata","tracking")]
    require(len(selected)==43 and sum(r["kind"]=="tracking" for r in selected)==20,"Expected 43 required tracking/metadata files")
    require(all(r["status"]=="VERIFIED" and len(r["sha256"])==64 for r in manifest["files"]),"Missing source SHA/status")
    required=[r["path"] for r in selected]
    require(required==plan["raw_files_to_copy_and_hash"],"Selected raw file set or order changed")
    source=Path(plan["raw_source_root"]).resolve()
    require(not source.is_relative_to(workspace) and not workspace.is_relative_to(source),"Raw source/output roots overlap")
    for row in selected:
        q=safe_join(source,row["path"])
        require(q.is_file() and q.stat().st_size==row["expected_bytes"],"Required source absent or size differs: "+row["path"])
    cache=safe_join(workspace,plan["cache_relative_path"]);prefix_dir=safe_join(workspace,plan["prefix_output_directory"])
    # Original save_prepared can overwrite: enforce both outputs absent before invoking it.
    require(not cache.exists() and not cache.with_suffix(".json").exists(),"Cache NPZ or adjacent metadata already exists")
    require(not prefix_dir.exists(),"Prefix output directory already exists")
    synthetic=safe_join(workspace,plan["synthetic_receipt"])
    require(not synthetic.exists(),"Fresh synthetic receipt required")
    raw_dest=safe_join(workspace,plan["raw_destination_relative"])
    require(not raw_dest.exists(),"Raw staging destination already exists")
    require(shutil.disk_usage(job).free>=plan["minimum_free_bytes"],"Insufficient free disk for independent copies and outputs")
    versions={k:importlib.metadata.version(k) for k in ("numpy","pandas","scipy")}
    require(versions==plan["runtime_package_versions"],"Runtime package versions differ from frozen preparation plan")
    return plan_path,plan,job,workspace,manifest,selected,source,cache,prefix_dir,synthetic,raw_dest,versions

def run(args):
    values=verified_plan(args)
    plan_path,plan,job,workspace,manifest,selected,source,cache,prefix_dir,synthetic,raw_dest,versions=values
    require(not (job/"execution01").exists(),"Create-only execution receipt directory already exists")
    if args.stage=="preflight":
        result={"status":"PASS_PREPARATION_PREFLIGHT_NO_RAW_CONTENT_READ","source_files":len(plan["source_files"]),
                "raw_files_present_size_checked":len(selected),"raw_source_files_hashed":0,"all_83_pins_preserved":True,
                "versions":versions,"scientific_outputs_created":False,"model_calls":0,"training_updates":0}
        print(json.dumps(result));return 0
    require(args.execute,"Real raw/cache stage requires explicit --execute")
    receipt=job/"execution01";receipt.mkdir()
    started=time.monotonic()
    write_new(receipt/"start.json",{"status":"STARTED_EXPLICIT_RAW20_REBUILD","utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "plan_sha256":args.plan_sha256,"wrapper_sha256":sha(__file__),"pid":os.getpid(),"python":sys.executable,
        "versions":versions,"scope":"Full cache reconstruction decodes historical 30-frame positions/velocities including future frames; subsequent prefix extraction decodes history only. No event data, model call or training."})
    before={}
    def event(value):
        with (receipt/"events.jsonl").open("a",encoding="utf-8") as f:f.write(json.dumps(value,ensure_ascii=False)+"\n")
        print(json.dumps(value,ensure_ascii=False),flush=True)
    def command(name,argv):
        before_pins={r["path"]:sha(safe_join(workspace,r["path"])) for r in plan["source_files"]}
        require(all(before_pins[r["path"]]==r["sha256"] for r in plan["source_files"]),"Source changed before command")
        t=time.monotonic();event({"stage":name,"status":"STARTED"})
        with (receipt/(name+".stdout.log")).open("x",encoding="utf-8") as stdout,(receipt/(name+".stderr.log")).open("x",encoding="utf-8") as stderr:
            result=subprocess.run([sys.executable,"-X","utf8","-B",*argv],cwd=workspace,stdout=stdout,stderr=stderr,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0,check=False)
        event({"stage":name,"status":"EXIT","exit_code":result.returncode,"seconds":time.monotonic()-t})
        require(result.returncode==0,"Original "+name+" returned nonzero; logs retained")
    try:
        copied=[]
        for row in selected:
            src=safe_join(source,row["path"]);dst=safe_join(raw_dest,row["path"])
            before[row["path"]]=stamp(src);dst.parent.mkdir(parents=True,exist_ok=True)
            h=hashlib.sha256();n=0
            with src.open("rb") as inp,dst.open("xb") as output:
                for b in iter(lambda:inp.read(1<<20),b""):
                    h.update(b);n+=len(b);output.write(b)
            require(stamp(src)==before[row["path"]],"Raw source changed while copying")
            require(n==row["expected_bytes"] and h.hexdigest()==row["sha256"],"Raw source SHA mismatch: "+row["path"])
            require(sha(dst)==row["sha256"] and dst.stat().st_size==n,"Independent copied source SHA mismatch")
            require(not os.path.samefile(src,dst),"Hardlink/same-file staging forbidden")
            copied.append({"path":row["path"],"bytes":n,"kind":row["kind"],"source_sha256":h.hexdigest(),"copy_sha256":row["sha256"],"independent_copy":True})
            event({"stage":"source_verified_and_copied","path":row["path"],"bytes":n,"sha256":row["sha256"]})
        write_new(receipt/"source_copy_receipt.json",{"files":copied,"hashed_and_copied":len(copied),
            "all_83_recorded_pins":plan["all_83_source_pins"],"not_read_or_copied_kinds":["events","phases"]})
        require(not cache.exists() and not cache.with_suffix(".json").exists(),"Cache outputs appeared before original parser")
        command("cache_parser",[plan["cache_parser"],"--output",plan["cache_relative_path"]])
        cache_hash=sha(cache)
        require(cache_hash==plan["expected_cache_sha256"] and cache.stat().st_size==plan["expected_cache_bytes"],"Exact historical cache byte identity failed; do not rewrite hash")
        write_new(receipt/"cache_identity.json",{"status":"PASS_EXACT_FULL20_CACHE","sha256":cache_hash,"bytes":cache.stat().st_size,
            "adjacent_metadata_sha256":sha(cache.with_suffix(".json")),"all_20_original_order_retained":True,
            "full_30_frame_numeric_values_decoded":True,"future_frames_decoded_for_historical_cache":True,
            "historical_future_qualified_admission_retained":True,"no_event_labels_read":True,"model_calls":0,"training_updates":0})
        command("prefix_synthetic",[plan["prefix_extractor"],"synthetic"])
        toy=read(synthetic)
        require(toy["status"]=="PASS_SYNTHETIC_PREFIX_AND_SLOT_AUDIT" and toy["source_sha256"]==plan["extractor_sha256"],"Fresh extractor synthetic gate failed")
        require(not prefix_dir.exists(),"Prefix outputs appeared before create-only extractor")
        command("prefix_prepare",[plan["prefix_extractor"],"prepare","--execute","--protocol-sha256",plan["original_protocol_sha256"],"--source-sha256",plan["extractor_sha256"]])
        prefix=prefix_dir/"test_prefixes.npz";pm=read(prefix_dir/"manifest.json")
        require(sha(prefix)==plan["expected_prefix_sha256"] and prefix.stat().st_size==plan["expected_prefix_bytes"],"Exact historical prefix byte identity failed")
        require(pm["sha256"]==plan["expected_prefix_sha256"] and pm["rows"]==4992 and pm["history_frames"]==10,"Prefix manifest identity/count differs")
        require(pm["input_archive_sha256"]==plan["expected_cache_sha256"] and pm["split_sha256"]==plan["split_sha256"],"Prefix input chain differs")
        require(pm["download_manifest_sha256"]==plan["download_manifest_sha256"],"Prefix download manifest identity differs")
        final_sources=[]
        for row in selected:
            src=safe_join(source,row["path"]);dst=safe_join(raw_dest,row["path"])
            source_final=sha(src);copy_final=sha(dst)
            require(source_final==copy_final==row["sha256"] and stamp(src)==before[row["path"]],"Source/copy changed after preparation")
            final_sources.append({"path":row["path"],"source_sha256":source_final,"copy_sha256":copy_final,"source_stat_unchanged":True})
        for row in plan["source_files"]:
            require(sha(safe_join(workspace,row["path"]))==row["sha256"],"Public source/metadata changed")
        require(sha(plan_path)==args.plan_sha256 and sha(__file__)==plan["wrapper_sha256"],"Plan/wrapper changed")
        require(sha(cache)==plan["expected_cache_sha256"],"Cache changed during prefix extraction")
        require(sha(Path(__file__).resolve().parent/"reconstruction_bindings.json")==plan["portable_binding_sha256"],"Portable binding changed during execution")
        for row in plan["source_files"]:
            require(sha(safe_join(Path(plan["public_source_root"]),row["public_path"]))==row["sha256"],"Public source tree changed during execution")
        write_new(receipt/"source_after_receipt.json",{"files":final_sources,"source_files_unchanged":True})
        result={"status":"PASS_PUBLIC_RAW20_EXACT_CACHE_AND_PREFIX","plan_sha256":args.plan_sha256,"git_commit":plan["git_commit"],
            "provider_revision":plan["provider_revision"],"raw_files_copied_and_hashed_before_and_after":43,"all_83_source_pins_preserved":True,
            "event_phase_files_decoded_or_copied":0,"cache_sha256":cache_hash,"cache_bytes":cache.stat().st_size,
            "prefix_sha256":sha(prefix),"prefix_bytes":prefix.stat().st_size,"prefix_rows":4992,
            "prefix_metadata_sha256":sha(prefix_dir/"metadata.json"),"prefix_manifest_sha256":sha(prefix_dir/"manifest.json"),
            "public_source_bytes_unchanged":True,"original_raw_bytes_unchanged":True,"model_calls":0,"training_updates":0,
            "cache_future_values_decoded":True,"prefix_extractor_future_values_materialized":False,
            "limits":"Reconstructs the historical future-qualified input population; not a new blind test, training rerun, factual scoring, new causal validation or whole-paper raw-to-result certification.",
            "seconds":time.monotonic()-started}
        write_new(receipt/"completion.json",result);print(json.dumps(result));return 0
    except BaseException as error:
        failure={"status":"FAILED_RETAINED_NO_GUARD_RELAXATION","plan_sha256":args.plan_sha256,"error_type":type(error).__name__,
            "error":str(error),"seconds":time.monotonic()-started,"outputs_retained":True,"do_not_resume_or_overwrite":True,
            "model_calls":0,"training_updates":0}
        if not (receipt/"completion.json").exists():write_new(receipt/"completion.json",failure)
        print(json.dumps(failure),file=sys.stderr,flush=True);raise

BINDING_SHA256 = "9b14847fb15232a3e49e51f6e78391e35174c4ad4f03374f8c6896af60ad9dc9"

def main():
    parser=argparse.ArgumentParser(
        description="Rebuild the exact historical 20-match SkillCorner cache and 4,992 history prefixes using pinned public source. Default: check prerequisites only.")
    parser.add_argument("--repo",required=True,help="Git clone root containing bundles/diagnostic_exact/workspace")
    parser.add_argument("--provider-root",required=True,help="Lawfully obtained fixed SkillCorner repository root containing data/matches")
    parser.add_argument("--out",required=True,help="New empty output root; must not exist")
    parser.add_argument("--execute",action="store_true",help="Copy verified sources and execute original cache/prefix preparation")
    args=parser.parse_args()
    here=Path(__file__).resolve().parent
    binding_path=here/"reconstruction_bindings.json"
    require(sha(binding_path)==BINDING_SHA256,"Portable binding file changed")
    plan=read(binding_path)
    repo=Path(args.repo).resolve();provider=Path(args.provider_root).resolve();job=Path(args.out).resolve()
    require(repo.is_dir() and provider.is_dir(),"Explicit repository/provider directories required")
    require(not job.exists(),"Output root must not exist: create-only, no resume")
    require(not job.is_relative_to(repo) and not repo.is_relative_to(job),"Output and public repository must not overlap")
    require(not job.is_relative_to(provider) and not provider.is_relative_to(job),"Output and provider source must not overlap")
    require(not here.is_relative_to(job),"Output must not contain the helper")
    expected_source={r["path"]:r for r in plan["source_files"]}
    for row in plan["source_files"]:
        source=safe_join(repo,row["public_path"])
        require(source.is_file(),"Missing source "+row["public_path"]+"; use a complete Git source tree. The published clone includes the required manifest/split.")
        require(source.stat().st_size==row["bytes"] and sha(source)==row["sha256"],"Public source differs: "+row["public_path"])
        if source.suffix==".py":ast.parse(source.read_text(encoding="utf-8-sig"),filename=str(source))
    manifest=read(safe_join(repo,expected_source[plan["download_manifest"]]["public_path"]))
    require(manifest["commit"]==plan["provider_revision"] and manifest["status"]=="COMPLETED","Provider revision/status differs")
    require(manifest["matches"]==plan["matches_in_original_order"],"Original match order differs")
    require([{"path":r["path"],"kind":r["kind"],"bytes":r["expected_bytes"],"sha256":r["sha256"]} for r in manifest["files"]]==plan["all_83_source_pins"],"Original 83-file inventory differs")
    selected=[r for r in manifest["files"] if r["kind"] in ("metadata","tracking")]
    require(len(selected)==43 and [r["path"] for r in selected]==plan["raw_files_to_copy_and_hash"],"Required source set differs")
    for row in selected:
        source=safe_join(provider,row["path"])
        require(source.is_file() and source.stat().st_size==row["expected_bytes"],"Provider file missing or size differs: "+row["path"])
    versions={k:importlib.metadata.version(k) for k in ("numpy","pandas","scipy")}
    require(versions==plan["runtime_package_versions"],"Original preparation package versions differ")
    ancestor=job.parent
    while not ancestor.exists():ancestor=ancestor.parent
    require(shutil.disk_usage(ancestor).free>=plan["minimum_free_bytes"],"Insufficient free output disk")
    if not args.execute:
        print(json.dumps({"status":"PASS_PORTABLE_PREREQUISITES_NO_RAW_CONTENT_READ","public_source_files":10,
            "source_tracking_and_roster_files":40,"copied_tracking_metadata_files_if_executed":43,
            "events_phases_files_not_read":40,"all_83_source_pins_preserved":True,"provider_files_size_checked":43,
            "versions":versions,"output_created":False,"model_calls":0,"training_updates":0}))
        return 0
    job.mkdir(parents=True,exist_ok=False);workspace=job/"workspace";workspace.mkdir()
    for row in plan["source_files"]:
        source=safe_join(repo,row["public_path"]);destination=safe_join(workspace,row["path"])
        data=source.read_bytes()
        require(len(data)==row["bytes"] and hashlib.sha256(data).hexdigest()==row["sha256"],"Public source changed during staging")
        destination.parent.mkdir(parents=True,exist_ok=True)
        with destination.open("xb") as f:f.write(data)
        require(sha(destination)==row["sha256"],"Staged public source bytes differ")
    plan.update({"job_root":str(job),"wrapper_sha256":sha(__file__),"raw_source_root":str(provider),
                 "public_source_root":str(repo),"portable_binding_sha256":BINDING_SHA256,
                 "created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 "stage":"SEALED_LOCAL_EXECUTION_PLAN_BEFORE_RAW_CONTENT_ACCESS"})
    plan_path=job/"execution_plan.json";write_new(plan_path,plan)
    dispatch=argparse.Namespace(plan=str(plan_path),plan_sha256=sha(plan_path),stage="run",execute=True)
    return run(dispatch)

if __name__=="__main__":raise SystemExit(main())
