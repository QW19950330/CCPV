# Reproducing the four-match trajectory results

Use this guide to reproduce the natural trajectory errors in Table 15/S12 and the model-input intervention responses in S11/S12. The commands use PowerShell. Run them from a short writable path in a fresh working directory. Keep this guide, `rebuild_skillcorner_prefixes.py` and `reconstruction_bindings.json` together in a subdirectory named `guide`.

## 1. Fix the versions and obtain the inputs

The reference execution used Python 3.11.5, NumPy 1.26.4, pandas 2.3.1, SciPy 1.11.1 and PyTorch 2.7.0. Model inference ran on CPU with the frozen FP32/MATH settings. Point `$py` at a Python environment with these packages. Keep at least 6 GiB free for input reconstruction, in addition to the provider checkout and prediction outputs.

```powershell
$ErrorActionPreference = 'Stop'
$py = (Get-Command python).Source
git -c core.autocrlf=false clone https://github.com/QW19950330/CCPV.git CCPV
if ($LASTEXITCODE) { throw 'Git clone failed' }
git -C CCPV -c core.autocrlf=false checkout --detach e63b1a380e401e82760c9c0e5ab0d4ebef339f23
if ($LASTEXITCODE) { throw 'Pinned checkout failed' }
& $py -X utf8 -B CCPV/verify_source_tree.py
if ($LASTEXITCODE) { throw 'Source verification failed' }
```

Obtain the data from SkillCorner at revision `4340d274572876239c154c90bc507a9b3250a656`. Set `$provider` below to its root, with `README.md`, `LICENSE`, `data/matches.json` and `data/matches/` directly inside. If you need a local copy, the optional PowerShell block below downloads the 43 required files (1.82 GB) from the provider URLs in the verified source manifest. It requires curl.exe. If you already have the files, skip the block. For a Git LFS checkout, supply the actual tracking data files. Git LFS pointer files fail the size check. The authors' test started with an existing provider copy and verified its bytes. [SkillCorner version and terms](https://github.com/SkillCorner/opendata/tree/4340d274572876239c154c90bc507a9b3250a656) · [Pinned file manifest](https://github.com/QW19950330/CCPV/blob/e63b1a380e401e82760c9c0e5ab0d4ebef339f23/bundles/diagnostic_exact/workspace/CCPV_data_expansion_20261022/artifacts/skillcorner_download_manifest.json).

```powershell
$manifest = Get-Content -Raw -Encoding UTF8 ./CCPV/bundles/diagnostic_exact/workspace/CCPV_data_expansion_20261022/artifacts/skillcorner_download_manifest.json | ConvertFrom-Json
$files = @($manifest.files | Where-Object { $_.kind -in 'metadata','tracking' })
if ($files.Count -ne 43) { throw 'Unexpected input inventory' }
$sourceRoot = Join-Path $PWD 'skillcorner-opendata'
foreach ($row in $files) {
    $dest = Join-Path $sourceRoot $row.path
    if (!(Test-Path -LiteralPath $dest)) {
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest)) | Out-Null
        $part = "$dest.download-$([guid]::NewGuid())"
        curl.exe --fail --location --retry 2 --output $part $row.url
        if ($LASTEXITCODE) { throw "Download failed for $($row.path)" }
        if ((Get-FileHash -LiteralPath $part).Hash -ne $row.sha256) { throw "Download hash mismatch for $($row.path)" }
        [IO.File]::Move($part,$dest)
    }
    if ((Get-FileHash -LiteralPath $dest).Hash -ne $row.sha256) { throw "Provider file mismatch for $($row.path)" }
}
```

```powershell
$repo = (Resolve-Path ./CCPV).Path
$provider = (Resolve-Path ./skillcorner-opendata).Path
$rebuilt = Join-Path $PWD 'rebuilt'
$entry = Join-Path $repo 'bundles/diagnostic_portable/run_clean_diagnostic.py'
$analysis = Join-Path $repo 'bundles/diagnostic_exact/workspace/CCPV_external_response_audit_20261119/analysis'
$binding = 'd4ba1fa402cbff99424c006fd44dfb7f50a558e05443b0e4eb7dc0be285fa85f'
$weightFile = 'CCPV_clean_inference_weights_local_candidate_20261119_v1.zip'
$weightHash = 'abef2dcb7742e36c0e4f9a50b40001390b6eb22f674eee3b34e72e30bf948f40'
Invoke-WebRequest -UseBasicParsing -Uri "https://zenodo.org/api/records/24370617/files/$weightFile/content" -OutFile $weightFile
if ((Get-FileHash $weightFile).Hash -ne $weightHash) { throw 'Weight archive mismatch' }
Expand-Archive -LiteralPath $weightFile -DestinationPath ./weights
```

## 2. Rebuild the historical inputs

The first command checks source code identities, provider file sizes, the environment and free space. The second checks provider content hashes, creates a new directory and runs the original parser, validation fixture and history extractor. Use a new output name for each attempt.

```powershell
& $py -X utf8 -B ./guide/rebuild_skillcorner_prefixes.py --repo $repo --provider-root $provider --out $rebuilt
if ($LASTEXITCODE) { throw 'Prerequisite check failed' }
& $py -X utf8 -B ./guide/rebuild_skillcorner_prefixes.py --repo $repo --provider-root $provider --out $rebuilt --execute
if ($LASTEXITCODE) { throw 'Input reconstruction failed' }
$base = Join-Path $rebuilt 'workspace'
$prefix = Join-Path $base 'CCPV_external_response_audit_20261119/skillcorner_prepared/test_prefixes.npz'
```

| Checkpoint | Expected result |
|---|---|
| Provider inputs | 20 tracking files, 20 match metadata files and three source metadata or licence files |
| Full cache | 24,826 windows across 20 matches. Train 14,886, validation 4,948, test 4,992 |
| Cache SHA-256 | `0e889418572d8c636171b101473b9428000596dc722f4e7ea053d056cab29091` |
| Test prefix SHA-256 | `a14904ed5a215805ce390fa0885b99e2e49752da096d47b119ba0019b0b8b656` |
| Prefix array artifact | 8,217,989 bytes. Ten history frames per window at 10 Hz, with validity masks |

The historical parser uses all 30 frames to form the player roster and applies the historical rule requiring future support. The subsequent model input contains the first ten frames. This procedure reproduces the retrospective cohort and its selection rules. Four test fixtures had been inspected during earlier work.

## 3. Run all five fixed models, the baseline and the six response paths

```powershell
& $py -X utf8 -B $entry preflight --binding-sha256 $binding --weights-root ./weights
if ($LASTEXITCODE) { throw 'Model preflight failed' }
& $py -X utf8 -B $entry run --binding-sha256 $binding --weights-root ./weights --prefixes $prefix --out ./predictions --all-planned
if ($LASTEXITCODE) { throw 'Full prediction failed' }
$predHash = (Get-FileHash ./predictions/completion.json).Hash.ToLowerInvariant()
& $py -X utf8 -B "$analysis/analyze_responses.py" --run-dir ./predictions --prediction-freeze-sha256 $predHash --out ./responses
if ($LASTEXITCODE) { throw 'Response analysis failed' }
```

The released D checkpoints are from epoch 4, update 96, seeds 0–4. CV is the constant-velocity baseline, evaluated once. Full execution uses the original batch size of 32 and includes all 4,992 windows for each model. Read `responses/seed_macros.csv` for individual seeds and `responses/five_seed_equal_match_summary.csv` for the four-match, equal-weight summary. The first-step perturbation minus the natural trajectory at 2 s was 0.180978 ± 0.004979 standardized metre-equivalents for D.

## 4. Recover measured player positions after the prediction freeze

```powershell
$specHash = 'f52b0f4d91894263190880b354ed61558a3428ba6486fb5761debe5644002091'
& $py -X utf8 -B "$analysis/recover_truth.py" --base $base --run-dir ./predictions --prediction-freeze-sha256 $predHash --source-spec "$analysis/truth_source_spec.json" --source-spec-sha256 $specHash --out ./truth
if ($LASTEXITCODE) { throw 'Truth recovery failed' }
$truthHash = (Get-FileHash ./truth/completion.json).Hash.ToLowerInvariant()
& $py -X utf8 -B "$analysis/score_factual.py" --truth-dir ./truth --truth-completion-sha256 $truthHash --run-dir ./predictions --prediction-freeze-sha256 $predHash --out ./scores
if ($LASTEXITCODE) { throw 'Natural scoring failed' }
Import-Csv ./scores/natural_equal_match_five_seed.csv | Format-Table metric,D_mean,D_seed_sd,CV_once
```

Calculate completion hashes on your own files. Receipts may contain local paths. The reference ground-truth NPZ has SHA-256 `1d76d5dfcde855cb932871211e673449c9c4cd94738ce80548c22235a92036b8`. The recovery found all 99,840 requested future frames across the four fixtures. Score only detected, finite, jointly supported player positions. Missing detections stay missing. Ground truth is available for natural motion. The altered running paths have no observed counterfactual outcome.

| Metric | Scorable windows of 4,992 | D, five-seed mean ± sample SD | CV | Paired D minus CV |
|---|---:|---:|---:|---:|
| ADE over 2 s | 4,945 | 0.845678 ± 0.013692 | 0.877485 | −0.031807 |
| FDE at 1 s | 4,740 | 0.711102 ± 0.010763 | 0.727753 | −0.016651 |
| FDE at 2 s | 4,538 | 2.343202 ± 0.040534 | 2.461259 | −0.118057 |

Distances use metre-equivalents on a standardized 105 × 68 pitch. Each window averages its supported points. Each fixture averages its windows and the four fixtures have equal weight. Seed SD measures initialization variation on these same fixtures. See `natural_seed_macros.csv`, `natural_fixture_errors.csv`, `paired_D_minus_CV_fixture_errors.csv` and `natural_window_errors.csv.gz` for individual runs, fixtures and score support. The 20 paired fixture–seed differences favored D for ADE and 2 s FDE. One fixture–seed difference at 1 s favored CV.

The authors checked this workflow in stages on one Windows host. Raw reconstruction and model replay were connected by the exact prefix identity. The public model replay matched 936 frozen prediction blocks and all 11,232 arrays. The factual scorer used the replayed predictions and separately recovered provider positions. These tests cover the specified four-match results. Training from scratch, transfer to other software environments, prospective validation and match outcomes under a recommended action require separate evidence. [Published source snapshot](https://github.com/QW19950330/CCPV/tree/e63b1a380e401e82760c9c0e5ab0d4ebef339f23) · [Fixed companion archives](https://doi.org/10.5281/zenodo.24370617).

